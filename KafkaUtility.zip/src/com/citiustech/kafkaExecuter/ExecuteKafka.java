package com.citiustech.kafkaExecuter;

import com.citiustech.kafkaStartupUtility.DataConsumer;
import com.citiustech.kafkaStartupUtility.DataProducer;

public class ExecuteKafka {

	public static void main(String[] args) {
//		DataProducer.publishMessages();
		DataConsumer.subscribeMessages();
	}
}
