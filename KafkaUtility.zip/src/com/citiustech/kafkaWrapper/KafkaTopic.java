package com.citiustech.kafkaWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;

import com.citiustech.resource.ConfigReader;
/**
@author Abhishek Altekar
	Wrapper to perform Kafka topic related operations
		1. Create kafka topic.
		2. Get list of all kafka topics.
		3. Check kafka topic present or not. 

*/
public class KafkaTopic {

	public static void createTopic(String topicName, int partitions, int replicationFactor) {
		try {
			Properties properties = new Properties();
			properties.setProperty("bootstrap.servers", ConfigReader.readConfigFile().getProperty("bootstrap.servers"));

			if (!topicExists(topicName)) {
				AdminClient adminClient = AdminClient.create(properties);
				NewTopic newTopic = new NewTopic(topicName, partitions, (short) replicationFactor);
				// new NewTopic(topicName, numPartitions,replicationFactor)
				List<NewTopic> newTopics = new ArrayList<NewTopic>();
				newTopics.add(newTopic);

				adminClient.createTopics(newTopics);
				adminClient.close();
				System.out.println("Topic with name '" + topicName + "' created successfully!");
			} else {
				System.out.println("Topic with name '" + topicName + "' already exists!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static Set<String> getAllTopics() {
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", ConfigReader.readConfigFile().getProperty("bootstrap.servers"));
		try (AdminClient client = AdminClient.create(properties)) {
			ListTopicsOptions options = new ListTopicsOptions();
			options.listInternal(true); // includes internal topics such as__consumer_offsets
			ListTopicsResult topics = client.listTopics(options);
			Set<String> currentTopicList = topics.names().get();
//			System.out.println(currentTopicList);
			return currentTopicList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean topicExists(String topic) {
		boolean topicExists = false;
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", ConfigReader.readConfigFile().getProperty("bootstrap.servers"));
		AdminClient admin = AdminClient.create(properties);
		try {
			topicExists = admin.listTopics().names().get().stream()
					.anyMatch(topicName -> topicName.equalsIgnoreCase(topic));
//			System.out.println(topicExists);
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return topicExists;
	}

	public static void main(String[] args) {
//		createTopic("MyFirstTopic", 2, 1);
		System.out.println(topicExists("MySecondTopic"));
		System.out.println(getAllTopics());
	}
}
