package org.one2one.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Laptop2 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;
	private String srno;
	private String make;

	public Laptop2() {
	}

	public Laptop2(String srno, String make) {
		this.srno = srno;
		this.make = make;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSrno() {
		return srno;
	}

	public void setSrno(String srno) {
		this.srno = srno;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	@Override
	public String toString() {
		return "Laptop [id=" + id + ", srno=" + srno + ", make=" + make + "]";
	}

}
