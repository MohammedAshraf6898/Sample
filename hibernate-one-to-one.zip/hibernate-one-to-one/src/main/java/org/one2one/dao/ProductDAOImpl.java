package org.one2one.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.one2one.model.Employee;
import org.one2one.util.HibernateUtil;

public class ProductDAOImpl extends ProductDAO {

	@Override
	public int save(Product c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(c);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> findAll() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Query query = session.createQuery("from Contact");
		List<Employee> contacts = query.getResultList();
		contacts.stream().forEach(System.out::println);
		session.getTransaction().commit();
		session.close();
		return contacts;
	}

	@Override
	public Employee findById(int id) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Employee c = session.load(Employee.class, id);
		System.out.printf("%s, %s", c.getName(), c.getEmail());
		return c;
	}

	@Override
	public int delete(Employee c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		c.setId(1);
		session.delete(c);
		session.getTransaction().commit();
		session.close();
		return 1;
	}

	@Override
	public int update(Employee c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.update(c);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

}
