package org.one2one.main;

import org.hibernate.Session;
import org.one2one.model.Employee;
import org.one2one.model.Laptop;
import org.one2one.util.HibernateUtil;

public class EmployeeLaptopTest {
	public static void main(String[] args) {

		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Laptop l = new Laptop("WB123", "Lenovo");
		session.save(l);

		Employee e = new Employee("Donald");
		e.setLaptop(l);

//		l.setEmployee(e);

		session.save(e);

		session.getTransaction().commit();
		session.close();

	}
}
