package org.inheritance.mapping.example3.model;

import javax.persistence.Entity;

@Entity
public class SavingAccount extends Account {

	private String customername;

	public SavingAccount() {
		// TODO Auto-generated constructor stub
	}

	public SavingAccount(String accno, String customername) {
		super(accno);
		this.customername = customername;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

}