package org.inheritance.mapping.example3.model;

import javax.persistence.Entity;

@Entity
public class CurrentAccount extends Account {

	private String companyname;

	public CurrentAccount() {
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(String accno, String companyname) {
		super(accno);
		this.companyname = companyname;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

}
