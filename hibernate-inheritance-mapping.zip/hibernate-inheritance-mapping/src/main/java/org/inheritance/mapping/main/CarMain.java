package org.inheritance.mapping.main;

import org.hibernate.Session;
import org.inheritance.mapping.model.PassengerCar;
import org.inheritance.mapping.model.SportCar;
import org.inheritance.mapping.util.HibernateUtil;

public class CarMain {
	public static void main(String[] args) {

		save();

	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		SportCar scar = new SportCar("Audi", "Turbo");
		PassengerCar pcar = new PassengerCar("BMW", 5);

		session.save(scar);
//		session.save(pcar);
		System.out.println("saved....");

		session.getTransaction().commit();
		session.close();
	}

}