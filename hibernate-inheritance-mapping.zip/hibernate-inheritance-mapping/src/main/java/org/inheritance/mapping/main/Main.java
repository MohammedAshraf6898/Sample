package org.inheritance.mapping.main;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.inheritance.mapping.model.Contractor;
import org.inheritance.mapping.model.Employee;
import org.inheritance.mapping.util.HibernateUtil;

public class Main {
	    public static void main(String[] args) {

	 

	    //    save();
	        read();
	        
	    }

	 

	    private static void save() {
	        Session session = HibernateUtil.getSession();
	        session.beginTransaction();
	        
	        Employee e = new Employee("John","Developer","IT");
	        Contractor c = new Contractor("Charles","Tester","Testing",12);
	        
	        session.save(e);
	        session.save(c);
	        System.out.println("saved....");
	    
	        session.getTransaction().commit();
	        session.close();
	    }
	    private static void read() {
	        Session session = HibernateUtil.getSession();
	        session.beginTransaction();
	        
	        Query query = session.createQuery("from Employee");
	        
	        List<Employee> cts  = query.getResultList();
	        for (Employee e : cts) {
	            if(e instanceof Contractor) {
	                Contractor c = (Contractor)e;
	                System.out.println(c.getId() + " : " + c.getName() + " : " + c.getDepartment() + " : "  + c.getDesignation()  + " : " + c.getDurationM());
	            }
	            else
	            System.out.println(e.getId() + " : " + e.getName() + " : " + e.getDepartment() + " : "  + e.getDesignation()  + " : ");
	        }
	    
	        session.getTransaction().commit();
	        session.close();
	    }
	}
