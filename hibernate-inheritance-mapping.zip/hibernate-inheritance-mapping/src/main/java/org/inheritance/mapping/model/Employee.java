package org.inheritance.mapping.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("E")
@Table(name ="tbl_Employee_InheritanceMapping")
public class Employee extends Person {

	private String designation;
	private String department;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(String name, String designation, String department) {
		super(name);
		this.designation = designation;
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

}