package org.inheritance.mapping.example3.model;

import org.hibernate.Session;
import org.inheritance.mapping.util.HibernateUtil;

public class AccountMain {
	public static void main(String[] args) {
		save();
	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		CurrentAccount ca = new CurrentAccount("123", "Starwars");
		session.save(ca);
		SavingAccount sa = new SavingAccount("456", "Jerry");
		session.save(sa);

		session.getTransaction().commit();
		session.close();
	}
}
