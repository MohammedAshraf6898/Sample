package org.inheritance.mapping.main;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.inheritance.mapping.model.Contractor;
import org.inheritance.mapping.model.Employee;
import org.inheritance.mapping.util.HibernateUtil;

public class PersonEmployeeMain {
	public static void main(String[] args) {
//		 save();
		read();
	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Employee e = new Employee("John", "Developer", "IT");
		Contractor c = new Contractor("Charles", "Tester", "Testing", 12);

		session.save(e);
		session.save(c);
		System.out.println("saved....");

		session.getTransaction().commit();
		session.close();
	}

	private static void read() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Query query = session.createQuery("from Employee");

		List<Employee> cts = query.getResultList();
		for (Employee c : cts) {
			System.out.println(c.getId() + " : " + c.getName());
		}

		session.getTransaction().commit();
		session.close();
	}
}