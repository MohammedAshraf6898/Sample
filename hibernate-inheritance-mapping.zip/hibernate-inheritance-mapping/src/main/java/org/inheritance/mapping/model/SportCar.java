package org.inheritance.mapping.model;

import javax.persistence.Entity;

@Entity
public class SportCar extends Car {

	private String type;

	public SportCar() {
	}

	public SportCar(String make, String type) {
		super(make);
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}