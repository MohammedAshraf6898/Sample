package org.inheritance.mapping.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("C")
@Table(name= "tbl_Contractor_InheritanceMapping")
public class Contractor extends Employee {

	private int durationM;

	public Contractor() {
		// TODO Auto-generated constructor stub
	}

	public Contractor(String name, String designation, String department, int durationM) {
		super(name, designation, department);
		this.durationM = durationM;
	}

	public int getDurationM() {
		return durationM;
	}

	public void setDurationM(int durationM) {
		this.durationM = durationM;
	}

}