package org.inheritance.mapping.model;

import javax.persistence.Entity;

@Entity
public class PassengerCar extends Car {

	private int seatcap;

	public PassengerCar() {
	}

	public PassengerCar(String make, int seatcap) {
		super(make);
		this.seatcap = seatcap;
	}

	public int getSeatcap() {
		return seatcap;
	}

	public void setSeatcap(int seatcap) {
		this.seatcap = seatcap;
	}

}