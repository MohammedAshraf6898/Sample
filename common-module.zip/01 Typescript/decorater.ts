export{}

function logger(constructor:Function){

    console.log("inside decorator");
    console.log(constructor);
}

@logger
class Person{
    name:string = "Abhishek";
}