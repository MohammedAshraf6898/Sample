var empInfo = [1, "Mark"];
console.log("Employee id: " + empInfo[0]);
for (var i = 0; i < 3; i++) {
    console.log("normal loop " + i);
}
console.log(" ****************** ");
var arr = [10, 20, 30];
for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
    var val = arr_1[_i];
    console.log(val);
}
console.log(" ****************** ");
for (var index in arr) {
    console.log(index);
    console.log(arr[index]);
}
var e;
e = "Hi";
e = 1;
// e = false // compile time error
var s;
s = "Hi";
s = 1;
// s = false // compile time error
function displayDate() {
    console.log(new Date());
}
displayDate();
