class Person{
    fn:string;
    ln:string;
    readonly city:string;
    // constructor(){
    //     console.log("constructor invoked");
    // }

    constructor(fn: string,ln: string,city: string){
        console.log(fn+" "+ln+" "+city);

    }
}

// new Person();

let p = new Person("Abhishek", "Altekar", "Pune");
p.fn = "Abhishek";
p.ln = "Altekar";
// p.city = "p"; // error as it's readonly
console.log(p.fn+" "+p.ln);
