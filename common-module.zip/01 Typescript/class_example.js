var Person = /** @class */ (function () {
    // constructor(){
    //     console.log("constructor invoked");
    // }
    function Person(fn, ln, city) {
        console.log(fn + " " + ln + " " + city);
    }
    return Person;
}());
// new Person();
var p = new Person("Abhishek", "Altekar", "Pune");
p.fn = "Abhishek";
p.ln = "Altekar";
console.log(p.fn + " " + p.ln);
