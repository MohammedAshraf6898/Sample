"use strict";
exports.__esModule = true;
var Employee = /** @class */ (function () {
    function Employee(fn, ln) {
        this.fn = fn;
        this.ln = ln;
    }
    Employee.prototype.fullname = function () {
        console.log(this.fn + " " + this.ln);
    };
    return Employee;
}());
var employee = new Employee("Abhishek", "Altekar");
var fullname = employee.fullname();
var emp = {
    fn: "Abhishek", ln: "Altekar",
    fullname: function () {
        console.log(this.fn + " " + this.ln);
    }
};
emp.fullname();
emp = employee;
emp.fullname();
