export { }
interface Person {
    fn: String;
    ln: string;
    fullname();
}

class Employee implements Person {

    fn: string;
    ln: string;
    fullname() {
        console.log(this.fn + " " + this.ln);
    }

    constructor(fn: string, ln: string) {
        this.fn = fn;
        this.ln = ln;
    }
}

let employee = new Employee("Abhishek", "Altekar");

let fullname = employee.fullname();

let emp: Person = {
    fn: "Abhishek", ln: "Altekar",
    fullname() {
        console.log(this.fn + " " + this.ln);
    }
}

emp.fullname();

emp =employee;
emp.fullname();