//Optional parameters
var X = /** @class */ (function () {
    function X() {
    }
    X.prototype.error = function (message, title, autoHideAfter) {
        console.log(message, title, autoHideAfter);
    };
    return X;
}());
// new X().error("hi there", undefined, 1000);
// default parameters
var Y = /** @class */ (function () {
    function Y() {
    }
    Y.prototype.error = function (message, autoHideAfter) {
        if (autoHideAfter === void 0) { autoHideAfter = 10; }
        console.log(message, autoHideAfter);
    };
    return Y;
}());
// new Y().error("Hello");
var RestParameterExample = /** @class */ (function () {
    function RestParameterExample() {
    }
    RestParameterExample.prototype.display = function (message) {
        var message2 = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            message2[_i - 1] = arguments[_i];
        }
        console.log(message + " " + message2.join(" | "));
    };
    ;
    return RestParameterExample;
}());
new RestParameterExample().display("Hello", "Abhishek", "INDIA");
(function () {
    console.log("default arrow function");
});
();
