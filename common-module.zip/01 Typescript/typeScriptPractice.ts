//Optional parameters
class X {
    error(message: string, title?: string, autoHideAfter?: number) {
        console.log(message, title, autoHideAfter);
    }
}

// new X().error("hi there", undefined, 1000);

// default parameters
class Y{

    error(message: string,  autoHideAfter: number = 10) {
        console.log(message, autoHideAfter);
    }
}
// new Y().error("Hello");


class RestParameterExample{

    display(message:string,... message2:string[]){
        console.log(message+" "+message2.join(" | "));
    };

 
}

new RestParameterExample().display("Hello", "Abhishek", "INDIA");

var q =()=>{
    console.log("default arrow function");
}

();
