var msg:string="Hello,Welcome to Typescript training";
console.log(msg)
var no1:number = 10;
var no2:number = 20;
var add: number = no1 + no2;
console.log(add);
var isActive:boolean = true;
console.log(isActive);
var anyValue:any;
anyValue = 'String value';
console.log(anyValue);
anyValue=100;
console.log(anyValue);
let message:string;
message= "Hello";
console.log(message);
const val = 100;
console.log(val);