var emp = {
    eId :1,
    eName: "Abhishek"

}
console.log(emp.eName);