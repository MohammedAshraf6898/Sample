let empInfo:[number, string]  = [1,"Mark"]
console.log("Employee id: "+empInfo[0]);


for(let i=0; i<3; i++){
    console.log("normal loop "+i)
}
console.log(" ****************** ")
let arr = [10,20,30]
for(let val of arr){
    console.log(val);
}
console.log(" ****************** ")
for(let index in arr){
    console.log(index);
    console.log(arr[index]);
}

let e: string | number

e = "Hi"
e = 1
// e = false // compile time error


let s: (string | number)

s = "Hi"
s = 1
// s = false // compile time error

function displayDate(){
    console.log(new Date());
}
displayDate();