--create table tbl_dept(
--deptno int,
--dname varchar(30),
--loc varchar(30)
--)

insert into tbl_dept 
select 10, 'acct', 'mum'
union select 20, 'fin', 'bang'
union select 30, 'oper', 'che'
union select 40, 'sales', 'pune'

select * from tbl_dept go

sp_help 'tbl_dept' go
sp_help 'hr.sal' go

sp_helpdb citius

truncate table tbl_dept
