--inner join
select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from emp e join dept d
on e.deptno = d.deptno where sal >2000

-- equi join
select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from emp e ,dept d
where e.deptno = d.deptno

-- left outer join
select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from emp e left outer join dept d
on e.deptno = d.deptno 

select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from dept d left outer join emp e 
on e.deptno = d.deptno 

-- right outer join
select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from emp e right outer join dept d
on e.deptno = d.deptno 

select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from dept d right outer join emp e 
on e.deptno = d.deptno 

-- full outer join
select distinct ename, sal, dname, loc,e.deptno Emp_Dept, d.deptno Dept
from emp e full outer join dept d
on e.deptno = d.deptno 

-- Self join
select a.ename, a.sal, b.ename, b.sal
from emp a join emp b
on a.mgr = b.empno

--non equi join

select a.ename, b.ename , a.job , b.job
from emp a join emp b
on a.job= b.job and a.deptno<>b.deptno
