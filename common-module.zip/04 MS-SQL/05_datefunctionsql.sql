--identity(seed, increment)
create table #T (empno int identity(10,5), ename varchar(20), sal numeric(10,2));
insert into #T values('mike',200000), ('john',700000), ('tom',100000), ('jerry',100000) 
select * from #T
drop table #T

--copy of table
select * into copy_emp from emp
select * from copy_emp
drop table copy_emp

select * into copy_emp from emp where deptno = 10
select * from copy_emp
drop table copy_emp

------------------------------------------------------

create table copy_emp(
empno int, sal numeric(10,2), ename varchar(20)
)
insert into copy_emp
select empno,sal, ename from emp
drop table copy_emp


select top 3 * from emp 
select top 3 ename, sal from emp order by sal desc

--constraint

create table pr_dept(
deptno smallint constraint deptno_pk primary key,
dname varchar(20) not null,
loc varchar(20)  not null
)

insert into pr_dept values (10, 'acct', 'pune'), (20, 'fin', 'bang')
, (30, 'adm', 'mum')

select * from pr_dept

--drop table pr_dept

------------------------------------------------------

create table pr_emp(
empno numeric(4) constraint empno_pk primary key,
ename varchar(20) not null,
sal numeric(10,2) constraint sal_check check(sal>40000),
deptno smallint constraint deptno_fk  foreign key references pr_dept(deptno),
city varchar(20) default 'pune' constraint city_in check (city in ('pune', 'bang', 'hyd') /*and city like 'b%' */) ,
comm numeric (10,2) not null constraint comm_range check(comm between 10000 and 30000 ),
mobile char(10) constraint mobile_uk  unique,
hiredate date);

insert into pr_emp values (1, 'tom', 30000, 11, 'mumbai', 20000, 111)
insert into pr_emp values (1, 'tom', 50000, 10, 'bang', 20000, 111, '2021-01-01')
insert into pr_emp values (2, 'jerry', 45000, 20, 'bang', 20000, 112, '2021-01-15')
insert into pr_emp values (3, 'mike', 60000, 30, default, 20000, 113, '2021-02-21')
insert into pr_emp values(4, 'suraj', 60000, 20, 'bang', 20000, '11111','2021-05-27');insert into pr_emp values(5, 'jyoti', 60000, 10, default, 20000, '22222','2021-05-27');
select * from pr_emp
--drop table pr_emp 
truncate table pr_emp

create table empleave(
empno smallint,
stdate date,
enddate date,
constraint empno_cpk primary key(empno,stdate)
)


--Numeric function

select abs(-10)
select POWER(2,3)
select FLOOR(10.89)
select CEILING (10.89)
select sign(-20)
select sign(+20)
select sign(20)
select sign(0)
select round(8982.8245,2)
select round(8982.8255,2)
select round(8982.8255,0)
select round(8982.8255,-1) --nearest 10
select round(8982.8255,-2) --nearest 100
select round(8982.8255,-3) --nearest 100
select round(8442.8255,-3) --nearest 100
select SQRT(144)
select round(RAND()*5,0)

select left('INDIA',2)
select right('INDIA',2)

select upper('india')
select lower('INDIA')
select ename, ASCII(ename) from emp
select LTRIM(' India')
select RTRIM(' India ')
select TRIM(' India ')

--Date functions
select getdate()
select DATEADD(mm,1,GETDATE())
select DATEADD(dd,2,GETDATE())
select DATEDIFF(yy, '2020-9-11',GETDATE())



-- alter
create table alt_emp (empno smallint not null, ename varchar(20),sal numeric(20))

alter table alt_emp add comm int;
alter table alt_emp drop column comm
alter table alt_emp ALTER column ENAME varchar(40) not null
alter table alt_emp ALTER column empno smallint not null
alter table alt_emp add constraint empno_pk1 primary key (empno)

drop table alt_emp
sp_help alt_emp






