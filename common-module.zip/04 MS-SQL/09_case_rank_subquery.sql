select * from emp
select * from dept

select empno, ename,
case when deptno = 10 then 'acct'
when deptno = 20 then 'res'
when deptno = 30 then 'sale'
when deptno = 40 then 'oper'
END dname
from emp

SELECT empno, ename,
CASE WHEN job ='CLERK'  THEN 'A'
WHEN job = 'SALESMAN' THEN 'S'
WHEN job = 'MANAGER' THEN 'M'
WHEN job = 'ANALYST' THEN 'A'
WHEN job = 'PRESIDENT' THEN 'P'
END Job_Initial
FROM emp

---------------------------
--Ranking function
--1. Row_Number()
--2. rank()
--3. dense_rank()

select ename, sal,ROW_NUMBER() over (order by sal desc) [rank] from emp
select ename, sal,rank() over (order by sal desc) [rank] from emp
select ename, sal,dense_rank() over (order by sal desc) [rank] from emp

-----------------------------
--sub query

select ename from emp where job = (select job from emp where ename = 'SMITH')
select ename from emp where job IN (select job from emp where ename = 'SMITH' or ename = 'Allen' )

select * from emp where sal >all
(select sal from emp where deptno = 20)

select * from emp where sal >any
(select sal from emp where deptno = 20)

select * from emp where deptno =
(select deptno from dept where loc = 'New York')


select * from emp cross join dept where sal>1000
select ename, sal, comm, dname , loc from empcross join deptwhere sal > 1000 





