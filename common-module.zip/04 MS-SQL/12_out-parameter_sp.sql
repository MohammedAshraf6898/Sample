create procedure sp_getSal
( @Deptno int, @totalsal int output)

as 
begin 
select @totalsal =sum(sal) from emp where deptno = @Deptno 
end

declare @T int
exec sp_getSal
'FORD',@T output 
print @T
go

--to see names of all the proceduresselect name , type from sys.objectswhere type='p';