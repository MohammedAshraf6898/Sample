select BusinessEntityID EmpId, VacationHours VC from HumanResources.Employee

select BusinessEntityID EmpId, VacationHours - SickLeaveHours TotalHours from HumanResources.Employee


select BusinessEntityID EmpId, VacationHours VC from HumanResources.Employee
where VacationHours >=40

select BusinessEntityID EmpId, VacationHours VC, MaritalStatus from HumanResources.Employee
where MaritalStatus = 'M'


select BusinessEntityID EmpId, VacationHours VC, MaritalStatus from HumanResources.Employee
where MaritalStatus <> 'M'


select BusinessEntityID EmpId, VacationHours VC, MaritalStatus from HumanResources.Employee
where not MaritalStatus = 'M'

select BusinessEntityID EmpId, VacationHours VC, MaritalStatus from HumanResources.Employee
where MaritalStatus = 'S'

select BusinessEntityID EmpId, VacationHours VC, MaritalStatus from HumanResources.Employee
where not MaritalStatus = 'S'

select distinct JobTitle from HumanResources.Employee

select cast (BusinessEntityID as varchar ) +' has designation '+ JobTitle bid_job from HumanResources.Employee
select convert (varchar,BusinessEntityID) +' '+  JobTitle bid_job from HumanResources.Employee

select * from HumanResources.Employee
where cast (BirthDate as varchar) like '1974%'

select * from HumanResources.Employee
where  BirthDate like '1974%'


select * from HumanResources.Employee
where  BirthDate between '1974-1-1' and '1974-12-31' 

select * from HumanResources.Employee
where  BirthDate not between '1974-1-1' and '1974-12-31' 

select * from HumanResources.Employee
where BirthDate >=  '1974-1-1' and BirthDate <= '1974-12-31'

select * from HumanResources.Employee
where JobTitle = 'Design Engineer'

SELECT * FROM HumanResources.Employee
WHERE JobTitle = 'Design Engineer' or JobTitle = 'Senior Tool Designer' or JobTitle =  'Tool Designer';

SELECT * FROM HumanResources.Employee
WHERE JobTitle in ( 'Design Engineer','Senior Tool Designer', 'Tool Designer' )

SELECT * FROM HumanResources.Employee
WHERE JobTitle not in ( 'Design Engineer','Senior Tool Designer', 'Tool Designer' )


-------------------------------
--like predicate

select * from Person.Person where FirstName like 'R%'
select FirstName,* from Person.Person where FirstName like '%r'
select FirstName,* from Person.Person where FirstName like '%r%'
select FirstName,* from Person.Person where FirstName like '_____'
select FirstName,* from Person.Person where FirstName like '[meh]%'
select FirstName,* from Person.Person where FirstName not like '[meh]%'
select FirstName,* from Person.Person where FirstName like '[^meh]%'
select FirstName,* from Person.Person where FirstName like '[a-k]%'
select FirstName,* from Person.Person where FirstName like '___d%'
select FirstName,* from Person.Person where FirstName like '___d'

-- aggregate functions

select count(*) from Person.Person 
select count(MiddleName) from Person.Person 

select distinct MiddleName from Person.Person 
select sum(VacationHours) total from HumanResources.Employee
select avg(VacationHours) total from HumanResources.Employee

select distinct(size) from Production.Product
select ProductID, [Name], Size from Production.Product

select ProductID, [Name], Size from Production.Product where size is not null
--and Size not in ()
select null+100

select FirstName,isnull(MiddleName,'No Middle Name') MiddleName, LastName from Person.Person


select FirstName,isnull(MiddleName,'No Middle Name') MiddleName, LastName from Person.Person
where MiddleName is null

SELECT FirstName,isnull(MiddleName,'No Middle Name') MiddleName, LastName from Person.Person
WHERE MiddleName is not null

