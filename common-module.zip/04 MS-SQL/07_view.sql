--database object
--1 table
--2 view
--3 index
--4 synonym

-- view it's virtual logical table

CREATE VIEW V1 as
select empno,ename, sal from emp


select * from V1;

Create  VIEW V2 as
select empno,ename,deptno, sal from emp where sal>1000

select * from V2;

drop view v2