use AdventureWorks2019
select * from HumanResources.Employee

select BusinessEntityID, DATEDIFF(yy,birthdate,getdate()) AgeInYear from HumanResources.Employee

select BusinessEntityID, birthdate,DATEPART(dd,birthdate)  from HumanResources.Employee

select convert(varchar, DATEPART (dd,GETDATE())) +'/'+
convert(varchar, DATEPART (MM,GETDATE())) +'/'+
convert(varchar, DATEPART (yyyy,GETDATE()))

select DATENAME(DW,GETDATE())
select DATENAME(DY,GETDATE())

select DATENAME(hh,GETDATE())
select DATENAME(mi,GETDATE())


select DATENAME(dd,GETDATE()) + ' '+ DATENAME(mm,GETDATE())+ ' '+  DATENAME(yyyy,GETDATE()) 

--on delete cascade
--on update cascade



