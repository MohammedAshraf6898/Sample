create trigger emp_insert_trigger on emp_trigger
after insert
as
begin
	print 'this is insert triggered'
end;

create trigger emp_update_trigger on emp_trigger
after update
as
begin
	print 'this is update trigger'
	select * from inserted
	select * from deleted
end

insert into emp_trigger (empno,ename,sal) values (2,'jerry',45000)
update emp_trigger set ename = 'Tom' where empno= 1
delete from emp_trigger where empno =1 
select * from emp_trigger


create trigger emp_delete_trigger on emp_trigger
after delete
as
begin
	print 'this is delete trigger'
	select * from inserted
	select * from deleted
end

select * from sys.objects where type= 'tr'

alter table emp_trigger
disable trigger emp_insert_trigger 

alter table emp_trigger
enable trigger emp_insert_trigger 

alter table emp_trigger
disable trigger emp_delete_trigger 
alter table emp_trigger
disable trigger emp_update_trigger 
--raise error using trigger
create trigger emp_error_trigger
on emp_trigger
after delete
as
begin
	raiserror('Error: Can no delete the record!!!', 12,1);
	rollback tran
end

drop trigger emp_error_trigger


create table sal_history
(
empno int, oldsal int, newsal int
)


alter trigger emp_update_history_trigger
on emp_trigger
after update 
as begin
declare @eid int, @oldsal int, @newsal int
select @eid=i.empno from inserted i;
select @oldsal=d.sal from deleted d;
select @newsal=i.sal from inserted i;
insert into sal_history values(@eid, @oldsal, @newsal);
end

update emp_trigger set sal = 55000 where empno = 2

select * from sal_history
