--index

--create table emp_index(
--emp int not null,
--ename varchar(20),
--sal int,
--comm int
--)

insert into emp_index values(1, 'tom',20000, 300)
,(2, 'jerry',25000, 300)
,(3, 'Mice',10000, 500)
,(4, 'Cat',30000, 300)

create index ename_id on emp_index(ename);

select * from emp_index where ename  = 'Cat'

create table emp_index2(
empno int constraint empno_pk_index primary key ,
ename varchar(20),
sal int,
comm int
)

insert into emp_index2 values(1, 'tom',20000, 300)
,(2, 'jerry',25000, 300)
,(3, 'Mice',10000, 500)
,(4, 'Cat',30000, 300)

--on primary key creation clustered index gets created
--by default nonclustered index gets created when we create index separately
--create nonclustered index comm_id on emp_index2(comm);  

sp_help emp_index2


