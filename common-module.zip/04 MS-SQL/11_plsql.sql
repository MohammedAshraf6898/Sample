--PL/SQL--procedural lang structured query language ----features --1 create varibales--2 loop--3 if conditions--4 create subprograms--    stored procedure--    functions--    trigger--5 increases the performance of the query using batch--6 exception handling performed--7 cursor can be used to manipulate multiple recordsbegin	select 'Abhishek' 	print 'Abhishek' 	select 'Abhishek' enddeclare @String nvarchar (20)set @String = 'Abhishek'select @Stringbegin	declare @job nvarchar(20)	select @job = job from emp where empno = 7369	select @jobendbegin	declare @job1 nvarchar(20), @veid smallint = 7369	declare @sal numeric (10,2), @comm numeric (10,2)	select @job1 = job, @sal =sal, @comm =comm from emp where empno = @veid	select @job1, @sal, @commend
declare @vsal int
select @vsal = sal from emp 
where ename = 'smith'
print 'the old sal :'+ convert(varchar(20),@vsal)
if @vsal<1000
begin
--update emp
--set sal =sal+500 where ename = 'smith'
print 'updated salary is: '+ convert(varchar(20),@vsal)
end
else
print 'not updated'
godeclare @vsal int
select @vsal = sal from emp 
where ename = 'ford'
if @vsal>=5000
begin
print 'Excellent sal'
end
else if @vsal < 5000 and @vsal>=4000
print 'good sal'
else if @vsal < 4000 and @vsal>=3000
print 'avg sal'


declare @vid int = 1
while (@vid<=20)
begin
	print @vid;
	set @vid= @vid + 1;
end

--first 10 even numbers
declare @c int = 2
while (@c<=20)
begin
	print @c;
	set @c= @c+ 2;
end

--blocks
--anonymous block
--named block

;
create procedure ProcedureDemo as
 begin
declare @psal int
select @psal = sal from emp 
where ename = 'ford'
if @psal>=5000
begin
print 'Excellent sal'
end
else if @psal < 5000 and @psal>=4000
print 'good sal'
else if @psal < 4000 and @psal>=3000
print 'avg sal'

end



exec ProcedureDemo






