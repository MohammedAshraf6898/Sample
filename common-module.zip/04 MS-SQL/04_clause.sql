--ORDER BY
select * from emp order by empno 
select empno,ename, sal from emp order by ename
select empno,ename, sal from emp order by 3
select empno,ename, sal from emp order by sal+100
select empno,ename, sal+100 S from emp order by s

select empno, ename, deptno, sal from emp order by deptno --,sal

--Group by
select  deptno, sum(sal) totalSal, avg(sal) AvgSal, min(sal) minSal, max (sal) maxSal
from emp group by deptno order by deptno

select  deptno, count(empno) from emp group by deptno
select  deptno, count(job) from emp group by deptno
select  deptno, job, count(empno) from emp group by deptno, job order by deptno


select deptno, sum(sal) totsal from emp
where sal> 500 and ename like 'A%'
or job in ('CLERK', 'SALESMAN')
group by deptno
having sum(sal) > 500
order by deptno


