--create database citius
--go
--use citius
--go
--create schema hr

--create table hr.sal(
--empno int,
--basic int,
--hra int,
--da int);
--insert into hr.sal values(1,20000,1000,10000),(2,30000,1000,10000),(3,40000,2090,455)
--select * from hr.sal

--create table tbl_emp (id int, ename nvarchar(255))
--insert into tbl_emp 
--select 1, 'Abhishek' union
--select 2, 'Mike'


--update tbl_emp set ENAME = 'Abhi' where ename = 'ABHISHEK'
--delete from tbl_emp where id = 2

select * from tbl_emp;



