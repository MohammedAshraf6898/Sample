package org.firstapp.dao;

import java.util.List;

import javax.persistence.Query;

import org.firstapp.model.Contact;
import org.firstapp.util.HibernateUtil;
import org.hibernate.Session;

public class ContactDaoImpl implements ContactDao {

	@Override
	public int save(Contact c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(c);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Contact> findAll() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Query query = session.createQuery("from Contact");
		List<Contact> contacts = query.getResultList();
		contacts.stream().forEach(System.out::println);
		session.getTransaction().commit();
		session.close();
		return contacts;
	}

	@Override
	public Contact findById(int id) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact c = session.load(Contact.class, id);
		System.out.printf("%s, %s", c.getName(), c.getEmail());
		return c;
	}

	@Override
	public int delete(Contact c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		c.setId(1);
		session.delete(c);
		session.getTransaction().commit();
		session.close();
		return 1;
	}

	@Override
	public int update(Contact c) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.update(c);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

}
