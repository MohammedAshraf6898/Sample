package org.firstapp.dao;

import java.util.List;

import org.firstapp.model.Contact;

public interface ContactDao {

	public int save(Contact c);

	public List<Contact> findAll();

//	public Contact findById();

	public int delete(Contact c);

	public int update(Contact c);

	Contact findById(int id);
}
