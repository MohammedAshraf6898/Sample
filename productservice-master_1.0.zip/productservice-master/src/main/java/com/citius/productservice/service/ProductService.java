package com.citius.productservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.citius.productservice.model.Product;

@Service
public class ProductService {
	
	private List<Product> products = new ArrayList<Product>();
	
	public ProductService() {
		products.add(new Product(1,"Mouse",500,0,0));
		products.add(new Product(2,"Keyboard",600,0,0));
			
	}
	public List<Product> getProducts(){
		return products;
	}
	
	public Product getProduct(int id) {
		return null;
	}
}
