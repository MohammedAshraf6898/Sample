package rnd;

public class Emp<T> implements Comparable<T>{
	int id, name;

	public Emp(int id, int name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public int compareTo(T o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
