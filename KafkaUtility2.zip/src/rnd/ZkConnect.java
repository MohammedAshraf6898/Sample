package rnd;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.server.NIOServerCnxn;
import org.apache.zookeeper.server.ServerConfig;
import org.apache.zookeeper.server.ZooKeeperServer;
import org.apache.zookeeper.server.ZooKeeperServerMain;
import org.apache.zookeeper.server.admin.AdminServer.AdminServerException;
import org.apache.zookeeper.server.quorum.QuorumPeerConfig;

public class ZkConnect {
	private ZooKeeper zk;
	private CountDownLatch connSignal = new CountDownLatch(0);

	// Method to connect zookeeper, default port 0.0.0.0:2181
	public ZooKeeper connect(String host) throws Exception {
		zk = new ZooKeeper(host, 10000, new Watcher() {
			public void process(WatchedEvent event) {
				if (event.getState() == KeeperState.SyncConnected) {
					connSignal.countDown();
				}
			}
		});
		connSignal.await();
		return zk;
	}

	public void close() throws InterruptedException {
		zk.close();
	}

	public void createNode(String path, byte[] data) throws Exception {
		zk.create(path, data, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
	}

	public void updateNode(String path, byte[] data) throws Exception {
		zk.setData(path, data, zk.exists(path, true).getVersion());
	}

	public void deleteNode(String path) throws Exception {
		zk.delete(path, zk.exists(path, true).getVersion());
	}


	public static void main(String args[]) throws Exception {
		
		
		ZkConnect connector = new ZkConnect();
		ZooKeeper zk = connector.connect("0.0.0.0:2181"); // method invoked
 //		String newNode = "/SampleNodeDate" + new Date();
//		connector.createNode(newNode, new Date().toString().getBytes());
System.out.println(zk);
		List<String> zNodes = zk.getChildren("/", true);
		for (String zNode : zNodes) {
			System.out.println("ChildrenNode " + zNode);
		}
//		byte[] data = zk.getData("/zookeeper", true, zk.exists("/zookeeper", true));
//		System.out.println("GetData before setting");
//		for (byte dataPoint : data) {
//			System.out.print((char) dataPoint);
//		}

//		System.out.println("GetData after setting");
//		connector.updateNode(newNode, "Modified data".getBytes());
//		data = zk.getData(newNode, true, zk.exists(newNode, true));
//		for (byte dataPoint : data) {
//			System.out.print((char) dataPoint);
//		}
//		connector.deleteNode("/deepakDateTue Apr 27 12:24:13 IST 2021");
	}

}