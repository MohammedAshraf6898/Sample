package rnd;

import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.common.errors.UnknownTopicOrPartitionException;

import com.citiustech.kafkaUtility.ConfigReader;

public class ZooKeeperEmbedded {


	  public static void  deleteTopic(final String topic) {
//		    final Properties properties = new Properties();
//		    properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, brokerList());
			Properties properties = new Properties();
			properties.setProperty("bootstrap.servers", ConfigReader.readConfigFile().getProperty("bootstrap.servers"));
		    try (final AdminClient adminClient = AdminClient.create(properties)) {
		      adminClient.deleteTopics(Collections.singleton(topic)).all().get();
		    } catch (final InterruptedException e) {
		      throw new RuntimeException(e);
		    } catch (final ExecutionException e) {
		      if (!(e.getCause() instanceof UnknownTopicOrPartitionException)) {
		        throw new RuntimeException(e);
		      }
		    }
		  }

	  public static void main(String[] args) {
		deleteTopic("MySecondTopic");
	}
	}
