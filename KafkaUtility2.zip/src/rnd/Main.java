package rnd;

import java.util.TreeSet;

public class Main {
	public static void main(String[] args) {
		Emp  emp = new Emp(5,7);
		TreeSet< Emp> t = new TreeSet<>();
		t.add(emp);
		t.add(new Emp(2, 2));
		System.out.println(t.toString());
	}
}
