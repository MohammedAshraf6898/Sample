package com.citiustech.kafkaStartupUtility;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.citiustech.kafkaUtility.ConfigReader;
import com.citiustech.kafkaUtility.KafkaServerManager;
import com.citiustech.kafkaUtility.KafkaTopic;

public class DataConsumer {

	public static void subscribeData() {
		try {
			if (KafkaServerManager.getZookeeperStatus()) {
				if (KafkaServerManager.getKafkaServerStatus()) {
					@SuppressWarnings("resource")
					Scanner sc = new Scanner(System.in);
					System.out.println("--Subscribe data--");
					System.out.println("Enter the topic name:");
					String topicName = sc.nextLine();
					if (KafkaTopic.topicExists(topicName)) {
						setConsumerData(topicName);
					} else {
						System.out.println("Error: Kafka Topic '" + topicName + "' is not present!\n");

						System.out.println("Available kafka topics list:");
						List<String> topicList = new ArrayList<String>(KafkaTopic.getAllTopics());
						Collections.sort(topicList);

						int topicCounter = 1;
						for (String topic : topicList) {
							System.out.println(topicCounter + ". " + topic);
							topicCounter++;
						}
						System.out.println("\n--Subscribe data--");
						System.out.println("Enter the topic name:");
						topicName = sc.nextLine();
						if (KafkaTopic.topicExists(topicName)) {
							setConsumerData(topicName);
						}
					}
				} else {
					System.out.println("Error: Unable to connect Kafka server (server down)!");
				}
			} else {
				System.out.println("Error: Unable to connect Zookeeper server (server down)!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setConsumerData(String topicName) {
		try {
			Properties properties = ConfigReader.readConfigFile(); // Method invoked
			properties.put("bootstrap.servers", properties.getProperty("bootstrap.servers"));
			properties.put("group.id", properties.getProperty("group.id"));
			properties.put("enable.auto.commit", properties.getProperty("enable.auto.commit"));
			properties.put("key.deserializer", properties.getProperty("key.deserializer"));
			properties.put("value.deserializer", properties.getProperty("value.deserializer"));

			@SuppressWarnings("resource")
			KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);
			consumer.subscribe(Arrays.asList(topicName));

			System.out.println("Info: Polling the messages from kafka broker...");
			while (true) {
				ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
				for (ConsumerRecord<String, String> record : records) {
					System.out.printf("offset = %d, key = %s, value= %s\n", record.offset(), record.key(),
							record.value());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		subscribeData();
	}
}
