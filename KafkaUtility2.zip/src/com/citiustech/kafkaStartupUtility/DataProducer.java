package com.citiustech.kafkaStartupUtility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.PartitionInfo;

import com.citiustech.kafkaUtility.ConfigReader;
import com.citiustech.kafkaUtility.KafkaServerManager;
import com.citiustech.kafkaUtility.KafkaTopic;

public class DataProducer {

	public static void publishData() {
		try {
			if (KafkaServerManager.getZookeeperStatus()) {
				if (KafkaServerManager.getKafkaServerStatus()) {
					@SuppressWarnings("resource")
					Scanner sc = new Scanner(System.in);
					System.out.println("--Publish data--");
					System.out.println("Enter the topic name:");
					String topicName = sc.nextLine();
					
					if (KafkaTopic.topicExists(topicName)) {
						
						System.out.println("Enter partition:");
						String partition = sc.nextLine();

						System.out.println("\nEnter key (Optional):");
						String key = sc.nextLine();
						if (key.equalsIgnoreCase("")) {
							key = null;
						}
						System.out.println("\nEnter the data to publish");
						String message = sc.nextLine();

						setProducerData(topicName, partition, key, message); // Method invoked
					} else {
						System.out.println("Error: Kafka Topic '" + topicName + "' is not present!");

						do {

							System.out.println("Available kafka topics list:");
							List<String> topicList = new ArrayList<String>(KafkaTopic.getAllTopics());
							Collections.sort(topicList);

							int topicCounter = 1;
							for (String topic : topicList) {
								System.out.println(topicCounter + ". " + topic);
								topicCounter++;
							}

							System.out.println("\n--Menu--");
							System.out.println("1. Create new Topic");
							System.out.println("2. Publish data");
							System.out.println("3. Exit");
							String choice = sc.nextLine();
							switch (choice) {
							case "1":
								System.out.print("1. Create new topic:\nEnter the topic name: ");

								String scannerTopicName = sc.nextLine();
								System.out.println(scannerTopicName);
								System.out.println(KafkaTopic.topicExists(scannerTopicName));
								if (!KafkaTopic.topicExists(scannerTopicName)) {
									System.out.print("\nEnter topic parititions count: ");
									String scannerTopicPartitions = sc.nextLine();

									System.out.println(scannerTopicPartitions);

									System.out.print("Enter topic replication factor count: ");
									String scannerTopicReplicationFactor = sc.nextLine();
									System.out.println(scannerTopicReplicationFactor);

									KafkaTopic.createTopic(scannerTopicName, Integer.parseInt(scannerTopicPartitions),
											Integer.parseInt(scannerTopicReplicationFactor));
								} else {
									System.out.println("Warning: Topic already exists!");
									System.out.println("Do you want to continue? Yes/No ");
									continue;
								}
								break;

							case "2":
								System.out.println("2. Publish data");

								System.out.print("Enter the topic name: ");
								String topic = sc.nextLine();

								System.out.println("\nEnter partition:");
								String partition = sc.nextLine();

								System.out.println("\nEnter key (Optional):");
								String key = sc.nextLine();
								if (key.equalsIgnoreCase("")) {
									key = null;
								}
								System.out.println("\nEnter the data to publish");
								String message = sc.nextLine();

								setProducerData(topic.trim(), partition, key, message); // Method invoked
								break;
							case "3":
								System.out.println("Successfully terminated!");
								System.exit(0);
								break;
							}

							System.out.println("Do you want to continue? Yes/No ");
						} while (!sc.nextLine().trim().equalsIgnoreCase("No"));
					}
				} else {
					System.out.println("Error: Unable to connect Kafka server (server down)!");
				}
			} else {
				System.out.println("Error: Unable to connect Zookeeper server (server down)!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setProducerData(String topic, String partition, String key, String message) {
		try {
			Properties properties = ConfigReader.readConfigFile();
			properties.put("bootstrap.servers", properties.getProperty("bootstrap.servers"));
			properties.put("key.serializer", properties.getProperty("key.serializer"));
			properties.put("value.serializer", properties.getProperty("value.serializer"));

			@SuppressWarnings("resource")
			Producer<String, String> producer = new KafkaProducer<String, String>(properties);
			
			producer.partitionsFor(topic);
			
			if (!message.equalsIgnoreCase("")) {
				ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(topic,
						Integer.parseInt(partition), key, message);
				producer.send(producerRecord);
				System.out.println("Success: Producer has published data successfully!");
			}
//			producer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void getPartitionInfo(String topic) {
		try {
			Properties properties = ConfigReader.readConfigFile();
			properties.put("bootstrap.servers", properties.getProperty("bootstrap.servers"));
			properties.put("key.serializer", properties.getProperty("key.serializer"));
			properties.put("value.serializer", properties.getProperty("value.serializer"));

			@SuppressWarnings("resource")
			Producer<String, String> producer = new KafkaProducer<String, String>(properties);
			
			List<PartitionInfo> list =producer.partitionsFor(topic);
			for(PartitionInfo p:list) {
				System.out.println(p.partition());
			}
//			producer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public static void main(String[] args) {
		publishData();
//		getPartitionInfo("MyFirstTopic");
	}
}

//https://www.youtube.com/watch?v=jzUJPJvWQ18
