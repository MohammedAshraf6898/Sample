package com.citiustech.kafkaUtility;

import java.util.Properties;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.zookeeper.ZooKeeper;


public class KafkaServerManager {

	public static boolean getZookeeperStatus() {
		boolean zkStatus = true;
		try {
			ZkConnect connector = new ZkConnect();
			ZooKeeper zk = connector.connect(ConfigReader.readConfigFile().getProperty("bootstrap.zookeeper")); // method
			zk.getChildren("/", true);// throws exception if zookeeper server is down
		} catch (Exception e) {
			zkStatus = false;
		}
		return zkStatus;
	}

	public static boolean getKafkaServerStatus() {
		final int ADMIN_CLIENT_TIMEOUT_MS = 3000;
		boolean kakfaServerStatus = true;
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", ConfigReader.readConfigFile().getProperty("bootstrap.servers"));

		try (AdminClient client = AdminClient.create(properties)) {
			client.listTopics(new ListTopicsOptions().timeoutMs(ADMIN_CLIENT_TIMEOUT_MS)).listings().get();
		} catch (Exception e) {
//			e.printStackTrace();
			kakfaServerStatus = false;
		}
		return kakfaServerStatus;
	}

	public static void main(String[] args) {
		System.out.println("Zookeeper status: " + getZookeeperStatus());
		System.out.println("Kafka server status: " + getKafkaServerStatus());
	}
}
