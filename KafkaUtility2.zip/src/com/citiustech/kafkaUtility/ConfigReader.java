package com.citiustech.kafkaUtility;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

	public static final String path = "config.properties";

	public static Properties readConfigFile() {
		Properties properties = new Properties();
		try {
			FileReader reader = new FileReader(path);
			properties.load(reader);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

	public static void main(String[] args) {
		readConfigFile();
	}
}
