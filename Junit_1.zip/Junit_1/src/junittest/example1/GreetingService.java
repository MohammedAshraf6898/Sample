package junittest.example1;

public class GreetingService {
	    
	    public String greet() {
	        return "Welcome!!";
	    }
}
