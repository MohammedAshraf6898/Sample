import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import junittest.example1.GreetingService;

public class GreetingServiceTest {

	// system under test
	private GreetingService gs = new GreetingService();

	@Test
	public void testgreet() {
		assertEquals(gs.greet(), "Welcome!!");

	}
}
