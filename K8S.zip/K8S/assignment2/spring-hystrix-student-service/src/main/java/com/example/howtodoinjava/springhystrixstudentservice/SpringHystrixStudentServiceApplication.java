package com.example.howtodoinjava.springhystrixstudentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHystrixStudentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHystrixStudentServiceApplication.class, args);
	}
}
