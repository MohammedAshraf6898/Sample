package com.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProductDAOImpl implements ProductDAO {
    private Connection con = PgSQLConnection.getDbConnection();

    @Override
    public int save(Product product) {
        PreparedStatement stmt = null;
        int n = 0;
        String sql = "insert into products(id,name,price) values(?,?,?)";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, product.getId());
            stmt.setString(2, product.getName());
            stmt.setInt(3, product.getPrice());
            n = stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            return 0;
        }
        return n;
    }

 

    @Override
    public List<Product> findAll() {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Product> products = new ArrayList<Product>();
        String sql = "select *  from products";
        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                products.add(new Product(rs.getInt("id"), rs.getString("name"), rs.getInt("price")));
            }
            stmt.close();
            rs.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public Product findById(int id) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Product p = null;

        String sql = "select *  from products where id = ?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                p = new Product(rs.getInt("id"), rs.getString("name"), rs.getInt("price"));
            }
            stmt.close();
            rs.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return p;
    }

    @Override
    public int delete(int id) {
        PreparedStatement stmt = null;
        int n = 0;
        String sql = "delete from products where id = ?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);
            n = stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            return 0;
        }
        return n;
    }
}
 












