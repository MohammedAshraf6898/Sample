package com.product;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

public class ProductDAOImplNormal implements ProductDAO {

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAll() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Query query = session.createQuery("from Contact");
		List<Product> contacts = query.getResultList();
		contacts.stream().forEach(System.out::println);
		session.getTransaction().commit();
		session.close();
		return contacts;
	}

	@Override
	public int save(Product product) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		session.save(product);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

	@Override
	public Product findById(int id) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Product c = session.load(Product.class, id);
		return c;
	}

	@Override
	public int delete(int id) {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Product c = new Product();
		c.setId(1);
		session.delete(c);
		session.getTransaction().commit();
		session.close();
		return 1;
	}

}
