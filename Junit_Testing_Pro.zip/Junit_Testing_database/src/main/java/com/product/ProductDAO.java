package com.product;

import java.util.List;

public interface ProductDAO {
	public int save(Product product);

	public List<Product> findAll();

	public Product findById(int id);

	public int delete(int id);

}