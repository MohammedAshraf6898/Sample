package com.product;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ProductDAOTest {
	private ProductDAO productDAO;
	private Connection con;

	@BeforeEach
	public void setup() {
		dbinit();

	}

	@Test
	@DisplayName("findAll")
	public void testfindAll() {
		List<Product> products = productDAO.findAll();
		Product p = products.get(0);
		assertEquals(1, products.size());
		assertAll(() -> {
			assertEquals(101, p.getId());
		}, () -> {
			assertEquals("Camera", p.getName());
		}, () -> {
			assertEquals(10000, p.getPrice());
		});
	}

	@AfterEach
	public void tearDown() {
		dbclose();

	}

	private void dbclose() {
		try {
			con.rollback();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void dbinit() {
		con = PgSQLConnection.getDbConnection();
		try {
			con.setAutoCommit(false);
			con.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		productDAO = new ProductDAOImpl();
		String query = "insert into products(id,name,price) values(?,?,?)";

		try {
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, 103);
			pst.setString(2, "Speaker");
			pst.setInt(3, 18000);
			pst.executeUpdate();
			pst.close();
			System.out.println("data inserted in \'products\'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}