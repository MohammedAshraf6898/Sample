package com.mockpro.services;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.jar.Attributes.Name;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ShoppingCartServiceTest {

	ShoppingCartService service = new ShoppingCartService();

	@Test
	void onCreateTest() {
//		Product p =new Product("Headhphone", 1000);
//		service.addItem(p);
		assertEquals(0, service.getItemCount());
	}

	@Test
	void onEmptyTest() {
		assertEquals(0, service.getItemCount());
	}

	@Test
	@DisplayName("After Product Adding")
	void onProductAdd() {
		int initialCount = service.getItemCount();
		Product p1 = new Product("Headhphone", 1000);
		service.addItem(p1);
		Product p2 = new Product("Speaker", 1700);
		service.addItem(p2);
		Product p3 = new Product("Keyboard", 600);
		service.addItem(p3);
		System.out.println(initialCount + " " + service.getItemCount());

		if (initialCount < service.getItemCount()) {
			System.out.println("after adding");
			assertNotEquals(initialCount, service.getItemCount());
		}
	}

	@Test
	@DisplayName("After Product Removing")
	void onProductRemove() throws ProductNotFoundException {
		int initialCount = service.getItemCount();
		Product p1 = new Product("Headhphone", 1000);
		service.addItem(p1);
		Product p2 = new Product("Speaker", 1700);
		service.addItem(p2);
		Product p3 = new Product("Keyboard", 600);
		service.addItem(p3);
		int finalCount = service.getItemCount();
		service.removeItem(p3);
		int afterRemoveCount = service.getItemCount();
		System.out.println(initialCount + " " + finalCount + " " + afterRemoveCount);
		assertFalse(afterRemoveCount > finalCount);
	}
	
	
	@Test
	@DisplayName("getBalance")
	void getBalaceTest() throws ProductNotFoundException {
		double initialBalance = service.getBalance();
		System.out.println("* "+initialBalance );
		
		Product p1 = new Product("Headhphone", 1000);
		service.addItem(p1);
		System.out.println("* "+service.getBalance() );
		Product p2 = new Product("Speaker", 1700);
		service.addItem(p2);
		System.out.println("* "+service.getBalance() );
		Product p3 = new Product("Keyboard", 600);
		service.addItem(p3);
		
		
	}
}
