package com.junit.test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;

import java.time.Duration;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

public class JunitDemoTest {
    
    @Test
    public void testAssert() {
        assertEquals(1, 1);
        assertEquals("Hello", "Hello");
        assertNotEquals(1, 2);
        String s1 = "welcome";
        String s2 = s1;
        String s3 = "hello";
        assertSame(s1, s2);
        assertNotSame(s2, s3);
        assertArrayEquals(new int[] {1,2,3,4,5}, new int[] {1,2,3,4,5});
        int a[] = {100,200};
        int b[] = {100,200};
        assertArrayEquals(a, b);
        assertIterableEquals(Arrays.asList("Java","Spring"), Arrays.asList("Java","Spring"));
        assertThrows(ArithmeticException.class,()->{
            int x = 100/0;
        });
        
        assertTimeout(Duration.ofSeconds(2), ()->{
            Thread.sleep(1000);
                        
        });
        
        assertAll(()->{
            assertEquals(10, 10);
        },()->{
            assertNotEquals(20, 10);
        });
        
    }

 

}