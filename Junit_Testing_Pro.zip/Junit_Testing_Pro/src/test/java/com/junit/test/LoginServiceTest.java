package com.junit.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.junit.examples.LoginService;
import com.junit.examples.LoginServiceImpl;

public class LoginServiceTest {

	private LoginService loginService = new LoginServiceImpl();

	@Test
	@DisplayName("validlogin")
	public void testcheckvalid() {
		assertTrue(loginService.check("john", "123"));
		assertTrue(loginService.isStatus());
	}

	@Test
	@DisplayName("invalidlogin")
	public void testcheckinvalid() {
		assertFalse(loginService.check("winston", "123"));
		assertFalse(loginService.isStatus());
	}

	@Test
	@DisplayName("logout")
	@Disabled
	public void testlogout() {
		assertTrue(loginService.check("john", "123"));
		assertTrue(loginService.isStatus());
		assertFalse(loginService.logout("john"));
		assertFalse(loginService.isStatus());
	}

	@Test
	@DisplayName("currentusercheck")
	public void testcurrentuser() {
		assertTrue(loginService.check("john", "123"));
		assertTrue(loginService.isStatus());
		assertEquals(loginService.getCurrentUser(), "john");

	}

	@Test
	@DisplayName("usercount")
	public void testusercount() {
		assertEquals(loginService.getCount(), 0);
		assertTrue(loginService.check("john", "123"));
		assertEquals(loginService.getCount(), 1);

	}
}
