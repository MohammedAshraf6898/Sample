package com.junit.pro.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.junit.pro.AuthService;
import com.junit.pro.IAuthService;

public class AuthServiceTest {
    private IAuthService authService = new AuthService();
    
    @Test
    @Tag("loginrelated")
    public void testcheck() {
     assertTrue(authService.check("Jack", "Sparrow"));
        
    }

}