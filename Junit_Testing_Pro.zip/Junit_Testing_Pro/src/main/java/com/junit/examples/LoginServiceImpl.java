package com.junit.examples;

public class LoginServiceImpl implements LoginService {
	private boolean status;
	private String currentUser;
	private int count = 0;

	public int getCount() {
		return count;
	}

	public boolean isStatus() {
		return status;
	}

	public boolean check(String login, String password) {
		if (login.equals("john") && password.equals("123")) {
			this.status = true;
			this.currentUser = login;
			count++;
			return true;
		} else
			return false;
	}

	public boolean logout(String login) {
		this.status = false;
		count--;
		return false;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCurrentUser() {
		// TODO Auto-generated method stub
		return currentUser;
	}

}