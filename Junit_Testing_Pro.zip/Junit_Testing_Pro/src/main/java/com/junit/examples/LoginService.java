package com.junit.examples;

public interface LoginService {
	public boolean check(String login,String password);
    public boolean logout(String login);
    public boolean isStatus();
    public String getCurrentUser();
    public int getCount();


}
