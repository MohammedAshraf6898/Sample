package com.citiustech.impact.resource;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class ConfigReader {

	public static final String path = "lib/config.properties";

	public static HashMap<String, String> readConfigFile() {
		HashMap<String, String> hm = new HashMap<>();
		try {

			FileReader reader = new FileReader(path);
			Properties properties = new Properties();
			properties.load(reader);
			hm.put("driverName", properties.get("driverName").toString());
			hm.put("serverName", properties.get("serverName").toString());
			hm.put("dbUsername", properties.get("dbUsername").toString());
			hm.put("dbPassword", properties.get("dbPassword").toString());
			hm.put("dbName", properties.get("dbName").toString());
			hm.put("serializeFilePath", properties.get("serializeFilePath").toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return hm;
	}

	public static void main(String[] args) {
		readConfigFile();
	}
}
