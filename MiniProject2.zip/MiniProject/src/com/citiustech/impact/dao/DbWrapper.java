package com.citiustech.impact.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Map;
/**
 * @author  Abhishek Altekar
 * 		This class provides wrapper to database CRUD operation
 */

public class DbWrapper {

	static Connection con = DbConnection.getDbConnection();
	static ResultSet rs;

	// select dynamic records
	public static void selectRecords(String selectQuery) {
		try {
			if (con != null) {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(selectQuery);

				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
//				System.out.println(columnCount);
				Map<String, String> columns = new LinkedHashMap<>();
				for (int i = 1; i <= columnCount; i++) {
//					System.out.println(metaData.getColumnTypeName(i));
					columns.put(metaData.getColumnName(i), metaData.getColumnTypeName(i));
				}
				while (rs.next()) {
					for (Map.Entry<String, String> entry : columns.entrySet()) {

						if (entry.getValue().equalsIgnoreCase("INT")) {
							System.out.print(rs.getInt(entry.getKey()) + " ");
						}
						if (entry.getValue().equalsIgnoreCase("VARCHAR")) {
							System.out.print(rs.getString(entry.getKey()) + " ");
						}
					}
					System.out.println();
				}

				/*
				 * while (rs.next()) { System.out.println(rs.getInt(1) + "  " + rs.getString(2)
				 * + "  " + rs.getString(3)); }
				 */
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// return ResultSet object to map with User defined encapsulated/model class
	public static ResultSet selectRecordsList(String selectQuery) {
		try {
			if (con != null) {
				Statement stmt = con.createStatement();
				rs = stmt.executeQuery(selectQuery);
				return rs;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// insert records in database
	public static void insertRecord(String insertQuery) {
		try {
			if (con != null) {
				PreparedStatement stmt = con.prepareStatement(insertQuery);
				stmt.executeUpdate();
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// insert records in database
	public static void updateRecord(String updateQuery) {
		try {
			if (con != null) {
				PreparedStatement stmt = con.prepareStatement(updateQuery);
				stmt.executeUpdate();
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
