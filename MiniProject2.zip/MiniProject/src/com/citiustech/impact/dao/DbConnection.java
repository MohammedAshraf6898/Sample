package com.citiustech.impact.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;

import com.citiustech.impact.resource.ConfigReader;
/**
 * @author  Abhishek Altekar
 * 		This singleton class provides Connection object 
 */

public class DbConnection {
	private static Connection conn = null;

	private DbConnection() {

	}

	public static Connection getDbConnection() {
		HashMap<String, String> dbConfig = ConfigReader.readConfigFile();

		try {
			Class.forName(dbConfig.get("driverName"));
			conn = DriverManager.getConnection(dbConfig.get("serverName") + dbConfig.get("dbName"),
					dbConfig.get("dbUsername"), dbConfig.get("dbPassword"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
