package com.citiustech.impact.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.impact.applicationEntities.Customer;
/**
 * @author  Abhishek Altekar
 * 		This class performs database related operations
 */

public class CustomerDAL {

	// Save Customer to tbl_Customer table in MySql database
	public static void saveCustomerDeails(Customer customer) {

		String insertCustomerQuery = "insert into tbl_customer (TradingPartnerName,City,CreditLimit,EmailId) values ('"
				+ customer.getTradingPartnerName() + "','" + customer.getCity() + "'," + customer.getCreditLimit()
				+ ",'" + customer.getEmailId() + "')";

		DbWrapper.insertRecord(insertCustomerQuery);

	}

	// Get all customers from database
	public static List<Customer> getAllCustomers() {
		List<Customer> allCustomerList = new ArrayList<>();
		try {
			ResultSet rs = DbWrapper.selectRecordsList("select * from tbl_customer");
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setTradingPartnerId(rs.getInt("TradingPartnerId"));
				customer.setTradingPartnerName(rs.getString("TradingPartnerName"));
				customer.setCity(rs.getString("City"));
				customer.setCreditLimit(rs.getInt("CreditLimit"));
				customer.setEmailId(rs.getString("EmailId"));
//				System.out.println(customer);
				allCustomerList.add(customer);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allCustomerList;
	}

	// Get single customer based on Id from database
	public static Customer getCustomerById(int customerId) {

		Customer customer = new Customer();
		try {
			ResultSet rs = DbWrapper
					.selectRecordsList("select * from tbl_customer where TradingPartnerId = " + customerId);
			while (rs.next()) {
				customer.setTradingPartnerId(rs.getInt("TradingPartnerId"));
				customer.setTradingPartnerName(rs.getString("TradingPartnerName"));
				customer.setCity(rs.getString("City"));
				customer.setCreditLimit(rs.getInt("CreditLimit"));
				customer.setEmailId(rs.getString("EmailId"));
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customer;
	}
	
	// Update customer info 
	public static void updateCustomer(Customer customer) {
		String updateQuery = "Update tbl_customer set TradingPartnerName = '" + customer.getTradingPartnerName()
		+ "', City = '" + customer.getCity() + "', CreditLimit = " + customer.getCreditLimit() + ", EmailId = '"
		+ customer.getEmailId() + "'   where TradingPartnerId = " + customer.getTradingPartnerId()+"";
//		System.out.println(updateQuery);
		try {
			DbWrapper.updateRecord(updateQuery);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
