package com.citiustech.impact.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.impact.applicationEntities.Supplier;
/**
 * @author  Abhishek Altekar
 * 		This class performs database related operations
 */

public class SupplierDAL {
	// Save supplier to tbl_Supplier table in MySql database
	public static void saveSupplierDeails(Supplier customer) {
		String insertSupplierQuery = "insert into tbl_supplier (TradingPartnerName,City,CreditBalance,PanNo) values ('"
				+ customer.getTradingPartnerName() + "','" + customer.getCity() + "'," + customer.getCreditBalance()
				+ ",'" + customer.getPanNo() + "')";
		DbWrapper.insertRecord(insertSupplierQuery);

	}
	// Get all suppliers from database
	public static List<Supplier> getAllSuppliers() {
		List<Supplier> allSupplierList = new ArrayList<>();
		try {
			ResultSet rs = DbWrapper.selectRecordsList("select * from tbl_Supplier");
			while (rs.next()) {
				Supplier supplier = new Supplier();
				supplier.setTradingPartnerId(rs.getInt("TradingPartnerId"));
				supplier.setTradingPartnerName(rs.getString("TradingPartnerName"));
				supplier.setCity(rs.getString("City"));
				supplier.setCreditBalance(rs.getInt("CreditBalance"));
				supplier.setPanNo(rs.getString("PanNo"));
//				System.out.println(supplier);
				allSupplierList.add(supplier);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return allSupplierList;
	}

	// Get single supplier based on Id from database
	public static Supplier getSupplierById(int supplierId) {
		Supplier supplier = new Supplier();
		try {
			ResultSet rs = DbWrapper
					.selectRecordsList("select * from tbl_Supplier where TradingPartnerId = " + supplierId);
			while (rs.next()) {
				supplier.setTradingPartnerId(rs.getInt("TradingPartnerId"));
				supplier.setTradingPartnerName(rs.getString("TradingPartnerName"));
				supplier.setCity(rs.getString("City"));
				supplier.setCreditBalance(rs.getInt("CreditBalance"));
				supplier.setPanNo(rs.getString("PanNo"));
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return supplier;
	}

	//Update supplier info
	public static void updateSupplier(Supplier supplier) {
		String updateQuery = "Update tbl_supplier set TradingPartnerName = '" + supplier.getTradingPartnerName()
				+ "', City = '" + supplier.getCity() + "', CreditBalance = " + supplier.getCreditBalance()
				+ ", PanNo = '" + supplier.getPanNo() + "'   where TradingPartnerId = " + supplier.getTradingPartnerId()
				+ "";
		System.out.println(updateQuery);
		try {
			DbWrapper.updateRecord(updateQuery);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
