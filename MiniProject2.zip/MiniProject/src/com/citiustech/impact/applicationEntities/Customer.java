package com.citiustech.impact.applicationEntities;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citiustech.impact.dao.CustomerDAL;

/**
 * @author  Abhishek Altekar
 * 		
 */
public class Customer extends TradingPartner implements Serializable {
	private static final long serialVersionUID = -2071026721661100838L;
	private int creditLimit;
	private String emailId;
	private static Customer customer;

	public Customer() {

	}

	public int getCreditLimit() {
		return creditLimit;
	}
	// setter method with validation
	public void setCreditLimit(int creditLimit) {
		error = "Error: Credit amount should not exceed limit of rupees 50,000/-";
		if (creditLimit >= 0 && creditLimit <= 50000) {
			this.creditLimit = creditLimit;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	public String getEmailId() {
		return emailId;
	}

	// setter method with validation
	public void setEmailId(String emailId) {
		String regex = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(emailId);
		error = "Error: Given email id is not valid";
		if (matcher.matches()) {
			this.emailId = emailId;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	// Binary serialize Customer object and save to file with '.ser' extension
	@Override
	public void saveToFile(String filePath) {
		// TODO Auto-generated method stub

		// Serialization
		try {
			// Saving of object in a file
			FileOutputStream file = new FileOutputStream(filePath);
			ObjectOutputStream out = new ObjectOutputStream(file);

			// Method for serialization of object
			out.writeObject(customer);
			out.close();
			file.close();
			System.out.println("Object has been serialized");
		}

		catch (IOException ex) {
			ex.printStackTrace();
//        	System.out.println("IOException is caught");
		}
	}

	// wrapper added to saveToFile method
	public void exportCustomer(int customerId, String filePath) {
		customer = CustomerDAL.getCustomerById(customerId);
		saveToFile(filePath);
	}
	
	// XML serialize Customer objects and save to file
	public void exportAllCustomersXmlSerialization(String filePath) {
		try {
			List<Customer> list = CustomerDAL.getAllCustomers();
			XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(filePath)));
			for (Customer customer : list) {
				encoder.writeObject(customer);
			}
			encoder.close();
			System.out.println("All customers successfully serialized");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
//	@Override
//	public String toString() {
//		return " tradingPartnerId(CustomerId)="
//				+ tradingPartnerId + "\t| tradingPartnerName(CustomerName)=" + tradingPartnerName + "\t| creditLimit=" + creditLimit + "\t| emailId=" + emailId + "\t| city=" + city + "";
//	}
	
	@Override
	public String toString() {
		return "Customer [creditLimit=" + creditLimit + ", emailId=" + emailId + ", tradingPartnerId="
				+ tradingPartnerId + ", tradingPartnerName=" + tradingPartnerName + ", city=" + city + "]";
	}
}
