package com.citiustech.impact.applicationEntities;

import java.util.ArrayList;

/**
 * @author  Abhishek Altekar
 * 		
 */
public abstract class TradingPartner {
	public int tradingPartnerId;
	public String tradingPartnerName, city;
	public static ArrayList<String> errorList = new ArrayList<>();
	String error;
	public int getTradingPartnerId() {
		return tradingPartnerId;
	}

	public void setTradingPartnerId(int tradingPartnerId) {
		if (tradingPartnerId > 0) {
			this.tradingPartnerId = tradingPartnerId;
		}
		else {
			errorList.add("Error: TradingPartnerId should be non-negative");
		}
	}

	public String getTradingPartnerName() {
		return tradingPartnerName;
	}

	public void setTradingPartnerName(String tradingPartnerName) {
		error = "Error: TradingPartnerName should have at least 5 characters";
		if (tradingPartnerName != null && tradingPartnerName.length() >= 5) {
			this.tradingPartnerName = tradingPartnerName;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		error = "Error: City should have at least 3 characters";
		if (city != null && city.length() >= 3) {
			this.city = city;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	@Override
	public String toString() {
		return "TradingPartner [tradingPartnerId=" + tradingPartnerId + ", tradingPartnerName=" + tradingPartnerName
				+ ", city=" + city + "]";
	}

	public String[] validate() {
		/*
		 * Object[] array = errorList.toArray(); for(Object o:array) { String s =
		 * (String) o; System.out.println(s); }
		 * 
		 */		
		String[] errorMessage =  errorList.toArray(new String[errorList.size()]);
//		for(String s:errorMessage ) {
//			System.out.println(s);
//		}
		return errorMessage;
	}

	public abstract void saveToFile(String filepath);
}
