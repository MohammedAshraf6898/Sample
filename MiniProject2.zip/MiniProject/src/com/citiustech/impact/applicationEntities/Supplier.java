package com.citiustech.impact.applicationEntities;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citiustech.impact.dao.SupplierDAL;
/**
 * @author  Abhishek Altekar
 * 		
 */
public class Supplier extends TradingPartner {
	private int creditBalance;
	private String panNo;
	Supplier supplier;

	public int getCreditBalance() {
		return creditBalance;
	}

	// setter method with validation
	public void setCreditBalance(int creditBalance) {
		super.error = "Error: Credit balance should not exceed limit of rupees 1,50,000/-";
		if (creditBalance >= 0 && creditBalance <= 150000) {
			this.creditBalance = creditBalance;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	public String getPanNo() {
		return panNo;
	}
	
	// setter method with validation
	public void setPanNo(String panNo) {
		String regex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(panNo);
		super.error = "Error: Pan Number should be in proper format ([5 alphabets] + [4 digits] + [1 alphabet])";
		if (panNo.length() == 10 && matcher.matches()) {
			this.panNo = panNo;
			errorList.removeIf(s -> s.equals(error));
		} else {
			errorList.removeIf(s -> s.equals(error));
			errorList.add(error);
		}
	}

	// XML serialize Supplier objects and save to file
	@Override
	public void saveToFile(String filePath) {
		// TODO Auto-generated method stub
		try {
			XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(filePath)));
			encoder.writeObject(supplier);
			encoder.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// wrapper added to saveToFile method
	public void exportSupplier(int supplierId, String filePath) {
		supplier = SupplierDAL.getSupplierById(supplierId);
		saveToFile(filePath);
	}

	@Override
	public String toString() {
		return "Supplier [creditBalance=" + creditBalance + ", panNo=" + panNo + ", tradingPartnerId="
				+ tradingPartnerId + ", tradingPartnerName=" + tradingPartnerName + ", city=" + city + "]";
	}

}
