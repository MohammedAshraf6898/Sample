package com.citiustech.impact.executor;

import java.util.ArrayList;
import java.util.Scanner;

import com.citiustech.impact.applicationEntities.Customer;
import com.citiustech.impact.applicationEntities.TradingPartner;
import com.citiustech.impact.dao.CustomerDAL;
/**
 * @author  Abhishek Altekar
 * This class provides console based User Interface for 'Customer'
 * 		
 */
public class CustomerUI {

	public static void addCustomerConsoleScreen() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		ArrayList<Customer> multipleCustomer = new ArrayList<>();
		do {
			Customer customer = new Customer();
			System.out.println("Enter Customer's Name:");
			String customerName = sc.nextLine();
			customer.setTradingPartnerName(customerName);
			System.out.println("Enter Customer's City:");
			String city = sc.nextLine();
			customer.setCity(city);
			System.out.println("Enter Customer's Credit Limit:");
			try {
				int creditLimit = Integer.parseInt(sc.nextLine());

				if (!(creditLimit > 50000) && !(creditLimit < 0)) {
					customer.setCreditLimit(creditLimit);
				} else {
					System.out.println("Enter Credit limit within 0 to 50000");
					creditLimit = Integer.parseInt(sc.nextLine());
					customer.setCreditLimit(creditLimit);
				}
			} catch (Exception e) {
				System.out.println("Not a valid number");
				int creditLimit = Integer.parseInt(sc.nextLine());
				customer.setCreditLimit(creditLimit);
			}
			System.out.println("Enter Customer's Email:");
			String emailId = sc.nextLine();
			customer.setEmailId(emailId);
			if (customer.getTradingPartnerName() != null && customer.getCity() != null && customer.getCreditLimit() >= 0
					&& customer.getCreditLimit() <= 50000 && customer.getEmailId() != null) {
				multipleCustomer.add(customer);
			}
			TradingPartner c = new Customer();
			String[] errorMessage = c.validate();
			for (String s : errorMessage) {
				System.out.println(s);
			}

			System.out.println("\nCustomer Menu: Do you want to continue? Yes/No");
		} while (!sc.nextLine().equalsIgnoreCase("No"));

		for (Customer cust : multipleCustomer) {
			if (cust != null) {
				CustomerDAL.saveCustomerDeails(cust);
				System.out.println("Customer info submitted successfully!");
			}
		}
	}
	
	public static void updateCustomerConsoleScreen() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Enter customer id to be updated:");
			Customer customer = CustomerDAL.getCustomerById(Integer.parseInt(sc.nextLine())); //Method invoked
			System.out.println("Before update\n"+customer);
			System.out.println("-- Update Menu --");
			System.out.println("1. Customer name");
			System.out.println("2. Customer city");
			System.out.println("3. Credit limit");
			System.out.println("4. Email id");
			System.out.println("5. Update all fields");
		
			// validate option for digit 
			int input;
			if (sc.hasNextInt() == true) {
				input = Integer.parseInt(sc.nextLine());
			} else {
				System.out.println("Please enter an integer value: ");
				sc.next();
				continue;
			}

			switch (input) {
			case 1:
				System.out.println("1. Customer name\nEnter new customer's name: ");
				String customerName = sc.nextLine();
				customer.setTradingPartnerName(customerName);
//				System.out.println(customerName + " "+ customer.getTradingPartnerName());
				CustomerDAL.updateCustomer(customer); //Method invoked
				System.out.println("Customer name updated successfully!");
				break;
			case 2:
				System.out.println("2. Customer city\nEnter new customer's city: ");
				customer.setCity(sc.nextLine());
				CustomerDAL.updateCustomer(customer); //Method invoked
				System.out.println("Customer: "+customer.getTradingPartnerName()+"'s city updated successfully!");
				break;
			case 3:
				System.out.println("3. Credit limit\nEnter new credit limit: ");
				customer.setCreditLimit(Integer.parseInt(sc.nextLine()));
				CustomerDAL.updateCustomer(customer); //Method invoked
				System.out.println("Customer: "+customer.getTradingPartnerName()+"'s credit limit updated successfully!");
				break;
			case 4:
				System.out.println("4. Email id\nEnter new customer's email id: ");
				customer.setEmailId(sc.nextLine());
				CustomerDAL.updateCustomer(customer); //Method invoked
				System.out.println("Customer: "+customer.getTradingPartnerName()+"'s email id updated successfully!");
				break;
			case 5:
				System.out.println("5. Update all fields");
				customer.setTradingPartnerName(sc.nextLine());
				customer.setCity(sc.nextLine());
				customer.setCreditLimit(Integer.parseInt(sc.nextLine()));
				customer.setEmailId(sc.nextLine());
				CustomerDAL.updateCustomer(customer); //Method invoked
				System.out.println("Customer: "+customer.getTradingPartnerName()+"'s info updated successfully!");
				break;
				
			default:
				System.out.println("Invalid option selected");
				break;
			}
			
			TradingPartner c = new Customer();
			String[] errorMessage = c.validate(); //Method invoked
			for (String s : errorMessage) {
				System.out.println(s);
			}
			
			System.out.println("After update\n"+customer);
			System.out.println("\nCustomer Menu: Do you want to continue? Yes/No");

		}while (!sc.nextLine().equalsIgnoreCase("No"));
	}
}
