package com.citiustech.impact.executor;

import java.util.ArrayList;
import java.util.Scanner;

import com.citiustech.impact.applicationEntities.Customer;
import com.citiustech.impact.applicationEntities.Supplier;
import com.citiustech.impact.applicationEntities.TradingPartner;
import com.citiustech.impact.dao.SupplierDAL;
/**
 * @author  Abhishek Altekar
 * This class provides console based User Interface for 'Supplier'
 * 		
 */

public class SupplierUI {
	public static void addSupplierConsoleScreen() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		ArrayList<Supplier> suppliers = new ArrayList<>();
		do {
			Supplier supplier = new Supplier();
			System.out.println("Enter Supplier Name:");
			supplier.setTradingPartnerName(sc.nextLine());
			System.out.println("Enter Supplier's City:");
			supplier.setCity(sc.nextLine());
			System.out.println("Enter Supplier's Credit Balance:");
			try {
				int creditBalance = Integer.parseInt(sc.nextLine());

				if (!(creditBalance > 150000) && !(creditBalance < 0)) {
					supplier.setCreditBalance(creditBalance);
				} else {
					System.out.println("Enter Credit balance within 0 to 150000");
					creditBalance = Integer.parseInt(sc.nextLine());
					supplier.setCreditBalance(creditBalance);
				}
			} catch (Exception e) {
				System.out.println("Not a valid number");
				int creditBalance = Integer.parseInt(sc.nextLine());
				supplier.setCreditBalance(creditBalance);
			}
			System.out.println("Enter Supplier's Pan Number");
			String panNumber = sc.nextLine();
			supplier.setPanNo(panNumber);

			if (supplier.getTradingPartnerName() != null && supplier.getCity() != null
					&& supplier.getCreditBalance() > 0 && supplier.getCreditBalance() <= 150000
					&& supplier.getPanNo() != null) {
				suppliers.add(supplier);
			}

			TradingPartner partner = new Supplier();
			String[] errorMessage = partner.validate();
			for (String s : errorMessage) {
				System.out.println(s);
			}
			System.out.println("\nSupplier Menu: Do you want to continue? Yes/No");
		} while (!sc.nextLine().equalsIgnoreCase("No"));

		for (Supplier supplier : suppliers) {
			if (supplier != null) {
				SupplierDAL.saveSupplierDeails(supplier);
				System.out.println(supplier + "\nHere, we can save the supplier");
			}
		}
	}

	public static void updateSupplierConsoleScreen() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Enter supplier id to be updated:");
			Supplier supplier = SupplierDAL.getSupplierById(Integer.parseInt(sc.nextLine()));
			System.out.println("Before update\n" + supplier);
			System.out.println("-- Update Menu --");
			System.out.println("1. Supplier name");
			System.out.println("2. Supplier city");
			System.out.println("3. Credit balance");
			System.out.println("4. Pan number");
			System.out.println("5. Update all fields");

			// validate option for digit
			int input;
			if (sc.hasNextInt() == true) {
				input = Integer.parseInt(sc.nextLine());
			} else {
				System.out.println("Please enter an integer value: ");
				sc.next();
				continue;
			}

			switch (input) {
			case 1:
				System.out.println("1. Supplier name\nEnter new supplier's name: ");
				String supplierName = sc.nextLine();
				supplier.setTradingPartnerName(supplierName);
//				System.out.println(customerName + " "+ customer.getTradingPartnerName());
				SupplierDAL.updateSupplier(supplier);
				System.out.println("Supplier's Name updated successfully!");
				break;
			case 2:
				System.out.println("2. Supplier city\nEnter new supplier's city: ");
				supplier.setCity(sc.nextLine());
				SupplierDAL.updateSupplier(supplier);
				System.out.println("Supplier: "+supplier.getTradingPartnerName()+"'s city updated successfully!");
				break;
			case 3:
				System.out.println("3. Credit balance\nEnter new credit balance: ");
				supplier.setCreditBalance(Integer.parseInt(sc.nextLine()));
				SupplierDAL.updateSupplier(supplier);
				System.out.println("Supplier: "+supplier.getTradingPartnerName()+"'s Credit balance updated successfully!");
				break;
			case 4:
				System.out.println("4. Pan Number\nEnter new supplier's pan number: ");
				supplier.setPanNo(sc.nextLine());
				SupplierDAL.updateSupplier(supplier);
				System.out.println("Supplier: "+supplier.getTradingPartnerName()+"'s Pan number updated successfully!");
				break;
			case 5:
				System.out.println("5. Update all fields");
				System.out.println("1. Supplier name\nEnter new supplier's name: ");
				supplier.setTradingPartnerName(sc.nextLine());
				System.out.println("2. Supplier city\nEnter new supplier's city: ");
				supplier.setCity(sc.nextLine());
				System.out.println("3. Credit balance\nEnter new credit balance: ");
				supplier.setCreditBalance(Integer.parseInt(sc.nextLine()));
				System.out.println("4. Pan Number\nEnter new supplier's pan number: ");
				supplier.setPanNo(sc.nextLine());
				SupplierDAL.updateSupplier(supplier);
				System.out.println("Supplier: "+supplier.getTradingPartnerName()+"'s info updated successfully!");
				break;

			default:
				System.out.println("Invalid option selected");
				break;
			}

			TradingPartner c = new Customer();
			String[] errorMessage = c.validate();
			for (String s : errorMessage) {
				System.out.println(s);
			}

			System.out.println("After update\n" + supplier);
			System.out.println("\nSupplier Menu: Do you want to continue? Yes/No");

		} while (!sc.nextLine().equalsIgnoreCase("No"));
	}

}
