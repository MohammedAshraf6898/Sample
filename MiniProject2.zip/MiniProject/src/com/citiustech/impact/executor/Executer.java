package com.citiustech.impact.executor;

import java.util.List;
import java.util.Scanner;

import com.citiustech.impact.applicationEntities.Customer;
import com.citiustech.impact.applicationEntities.Supplier;
import com.citiustech.impact.dao.CustomerDAL;
import com.citiustech.impact.dao.SupplierDAL;
import com.citiustech.impact.resource.ConfigReader;
/**
 * @author  Abhishek Altekar
 * This class console based User Interface
 * 		
 */
public class Executer {
	public void consoleUI() {

		Scanner menu = new Scanner(System.in);

		do {
			System.out.println("--- menu ---");
			System.out.println("1. Add Customer");
			System.out.println("2. Add Supplier");
			System.out.println("3. Show all Customers");
			System.out.println("4. Show all Suppliers");
			System.out.println("5. Export a Customer");
			System.out.println("6. Export a Supplier");
			System.out.println("7. Update a Customer");
			System.out.println("8. Update a Supplier");
			System.out.println("9. Export all Customer using XML serialization");
			System.out.println("10. Exit");
			
			// validate option for digit 
			int input;
			if (menu.hasNextInt() == true) {
				input = Integer.parseInt(menu.nextLine());
			} else {
				System.out.println("Please enter an integer value: ");
				menu.next();
				continue;
			}
			int srNo = 1; // Declared to set serial number in console
			switch (input) {
			
			case 1:
				System.out.println("1. Add Customer");
				CustomerUI.addCustomerConsoleScreen();
				break;

			case 2:
				System.out.println("2. Add Supplier");
				SupplierUI.addSupplierConsoleScreen();
				break;

			case 3:
				System.out.println("3. Show all Customers");
				List<Customer> allCustomers = CustomerDAL.getAllCustomers();
				System.out.println("Sr no.\t| CustomerId  \t| CustomerName   \t| creditLimit\t| emailId \t\t| city ");
				System.out.println("---------------------------------------------------------------------------------------------------");
				for (Customer customer : allCustomers) {
					System.out.format("%-5d   | %-10d   | %-20s  | %-10d  | %-25s  | %-10s",srNo, customer.getTradingPartnerId(),customer.getTradingPartnerName(),customer.getCreditLimit(),customer.getEmailId(),customer.getCity()).println();
//					System.out.println(""+i+". \t|"+customer);
					srNo++;
				}
				break;

			case 4:
				System.out.println("4. Show all Suppliers");
				List<Supplier> allSuppliers = SupplierDAL.getAllSuppliers();
				System.out.println("Sr no.\t| SupplierId  \t| SupplierName   \t| CreditBalance\t| PanNumber \t| City ");
				System.out.println("---------------------------------------------------------------------------------------------------");

				for (Supplier supplier : allSuppliers) {
					System.out.format("%-5d   | %-10d   | %-20s  | %-10d  | %-12s  | %-10s",srNo, supplier.getTradingPartnerId(),supplier.getTradingPartnerName(),supplier.getCreditBalance(),supplier.getPanNo(),supplier.getCity()).println();
//					System.out.println(""+i+". \t|"+customer);
					srNo++;
				}
				break;

			case 5:
				System.out.println("5. Export a Customer : \nPlease enter customer id = ");
				int customerId = Integer.parseInt(menu.nextLine());
				String filePath = ConfigReader.readConfigFile().get("serializeFilePath")
						+ "\\binary_serialized_customer_" + customerId + ".ser";
				Customer customer = new Customer();
				customer.exportCustomer(customerId, filePath);
				break;

			case 6:
				System.out.println("6. Export a Supplier : \nPlease enter supplier id = ");
				int supplierId = Integer.parseInt(menu.nextLine());
				String xmlFilePath = ConfigReader.readConfigFile().get("serializeFilePath")
						+ "\\xml_serialized_supplier_" + supplierId + ".xml";
				Supplier supplier = new Supplier();
				supplier.exportSupplier(supplierId, xmlFilePath);
				break;

			case 7:
				System.out.println("7. Update a Customer");
				CustomerUI.updateCustomerConsoleScreen();
				break;

			case 8:
				System.out.println("8. Update a Supplier");
				SupplierUI.updateSupplierConsoleScreen();
				break;

			case 9:
				System.out.println("9. Export all Customer using XML serialization");
				Customer customer1 = new Customer();
				customer1.exportAllCustomersXmlSerialization(ConfigReader.readConfigFile().get("serializeFilePath")
						+ "\\customer_xml_serialization_master.xml");
				break;

			case 10:
				System.out.println("Successfully terminated from Main Menu");
				return;

			default:
				System.out.println("Invalid option selected");
				break;
			}
			System.out.println("\nMain menu: Do you want to continue? Yes/No");
		} while (!menu.nextLine().equalsIgnoreCase("No"));
		menu.close();
		System.out.println("Successfully terminated from Main menu");

	}
}
