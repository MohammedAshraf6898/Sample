package com.citius.taxservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
