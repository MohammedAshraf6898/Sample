package org.one2one.dao;

import java.util.List;

import org.one2one.model.Employee;

public interface ContactDao {

	public int save(Employee c);

	public List<Employee> findAll();

//	public Contact findById();

	public int delete(Employee c);

	public int update(Employee c);

	Employee findById(int id);
}
