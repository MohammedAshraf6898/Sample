package com.citius.MSOne;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class MsOneApplication implements CommandLineRunner {

	@Autowired
	private RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public static void main(String[] args) {
		SpringApplication.run(MsOneApplication.class, args);
	}

	/*
	 * @Override public void run(String... args) throws Exception { String url =
	 * "http://localhost:8080/contacts/{id}";
	 * 
	 * Map<String, String> params = new HashMap<>(); params.put("id", "1");
	 * 
	 * Contact c = restTemplate.getForObject(url, Contact.class, params);
	 * System.out.println(c);
	 * 
	 * }
	 */

	@Override
	public void run(String... args) throws Exception {
		findById(); 

	}

	private void findById() {
		String url = "http://localhost:8080/contacts/{id}";

		Map<String, String> params = new HashMap<>();
		params.put("id", "1");

		ResponseEntity<Contact> res = restTemplate.getForEntity(url, Contact.class, params);
		System.out.println(res.getBody() + " : " + res.getStatusCode());
	}

	private void findAll() {
		String url = "http://localhost:8080/contacts";
		//write....code
		

	}
}
