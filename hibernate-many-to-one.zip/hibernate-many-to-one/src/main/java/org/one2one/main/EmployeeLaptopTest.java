package org.one2one.main;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.one2one.model.Department;
import org.one2one.model.Employee;
import org.one2one.util.HibernateUtil;

public class EmployeeLaptopTest {
	
	public static void main(String[] args) {
//		save();
		read();
	}

	@SuppressWarnings("unused")
	private static void read() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Query query = session.createQuery("from Department");

		List<Department> depts = query.getResultList();

		for (Department department : depts) {
			System.out.println(department.getId() + " : " + department.getName());
			for (Employee e : department.getEmployees()) {
				System.out.println(e.getName() + " : " + e.getId());
			}
		}

		session.getTransaction().commit();
		session.close();
	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Department sales = new Department("Sales");
		session.save(sales);

		Employee joe = new Employee("Joe");
		joe.setDepartment(sales);

		Employee donald = new Employee("Donald");
		donald.setDepartment(sales);

		session.save(joe);
		session.save(donald);

		session.getTransaction().commit();
		session.close();
	}
}