package com.citiustech.methodReferences;

public class MethodReferencesV2 {
	public static void main(String[] args) {

	}
}
