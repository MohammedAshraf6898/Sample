package com.citiustech.methodReferences;

public class MethodReferencesV1 {

	public static void main(String[] args) {
//		printMessage();
		System.out.println("Start");
//		Thread thread = new Thread(()-> printMessage());
		Thread thread = new Thread(MethodReferencesV1::printMessage);
		thread.start();
		System.out.println("End");
	}

	public static void printMessage() {
		System.out.println("Hello from printmessage");
	}
}
