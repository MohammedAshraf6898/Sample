package com.citiustech.streams;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class StreamSorted {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("9", "A", "Z", "1", "B", "Y", "4", "c", "a");
		Collections.sort(list);
//	System.out.println(list);

		Stream<String> sortedListStream = list.stream().sorted();
//	sortedListStream.forEach(System.out::print);

		list.stream().sorted().forEach(System.out::print);

		List<String> list2 = list.stream().sorted().collect(Collectors.toList());
//	System.out.println("\n"+list2);
		list2.forEach(System.out::print);

		System.out.println();
		List<String> list3 = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		list3.forEach(System.out::print);

		List<Person> people = Arrays.asList(new Person("Tom", "Cat"), new Person("Jerry", "Mouse"),
				new Person("Spike", "Dog"));
		List<Person> people2= people.stream().sorted((p1, p2) -> p1.getFirstName().compareTo(p2.getFirstName()))
		.collect(Collectors.toList());
		people2.forEach(System.out::println);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
