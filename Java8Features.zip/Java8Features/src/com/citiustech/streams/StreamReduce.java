package com.citiustech.streams;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;

public class StreamReduce {

	public static void main(String[] args) {

		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		// Print sum of arrays
		int sum = 0;

//		for(int i:numbers)
//			sum+=i;

//		System.out.println("Sum = "+sum);

		sum = Arrays.stream(numbers).reduce(0, new IntBinaryOperator() {

			@Override
			public int applyAsInt(int left, int right) {
				System.out.println("left = " + left + " right = " + right);
				return left + right;
			}
		});

		System.out.println("Sum = " + sum);
		System.out.println(
				"Sum using lambda expresssion = " + Arrays.stream(numbers).reduce(0, (left, right) -> left + right));

		System.out.println("Sum using method reference = " + Arrays.stream(numbers).reduce(0, Integer::sum));

	}
}
