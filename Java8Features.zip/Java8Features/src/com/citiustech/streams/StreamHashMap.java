package com.citiustech.streams;

import java.util.HashMap;
import java.util.Map;

public class StreamHashMap {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("one", "first");
		map.put("two", "second");
		map.put("three", "third");

//		Stream<String> stream = 
		map.keySet().stream().forEach(System.out::println);
		System.out.println("----------------------------");
		map.values().stream().forEach(System.out::println);
		
	}
}
