package com.citiustech.collectionIteration;

import java.util.Arrays;
import java.util.List;

import com.citiustech.optional.Person;

public class CollectionIterationExample {

	public static void main(String[] args) {
		   List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharelar", 33),
	                new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));


        // external iterators - Sequential Execution
        for (int i = 0; i < people.size(); i++) {
            System.out.println(people.get(i));
        }

        System.out.println("---------------------------");
        for (Person person : people) {
            System.out.println(person);
        }

        // interanl iterator - Parallel Execution
        System.out.println("---------------------------");
        System.out.println("Using Java 8 forEach method");
        people.forEach(p -> System.out.println(p));
        System.out.println("---------------------------");
        System.out.println("Using Java 8 Method Reference");
        people.forEach(System.out::println);
	}
}
