package com.citiustech.collectionIteration;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StreamCollectionMap {

	public static void main(String[] args) {
		List<String> alphabets = Arrays.asList("a", "b", "c", "d", "e");

		List<String> alphabetsUpper = alphabets.stream().map(new Function<String, String>() {

			@Override
			public String apply(String alphabet) {
				return alphabet.toUpperCase();
			}
		}).collect(Collectors.toList());

		alphabetsUpper.forEach(System.out::println);

		System.out.println(
				"***" + alphabets.stream().map(alphabet -> alphabet.toUpperCase()).collect(Collectors.toList()));

		System.out.println(
				"****" + alphabets.stream().map(StreamCollectionMap::alphabetToUpper).collect(Collectors.toList()));

		List<Person> people = Arrays.asList(new Person("Tom", "Cat"), new Person("Jerry", "Mouse"),
				new Person("Spike", "Dog"));
		people.stream().map(p -> p.getFirstName().toUpperCase()).forEach(p -> System.out.println(p));

	}

	public static String alphabetToUpper(String alphabet) {
		return alphabet.toUpperCase();
	}
}
