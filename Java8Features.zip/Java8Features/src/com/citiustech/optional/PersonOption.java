package com.citiustech.optional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class PersonOption {

	public static void main(String[] args) {
		   List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharelar", 33),
	                new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));
		   
		   Optional<Person> personOptional = findPerson(people, "Vivek____");
		   if(personOptional.isPresent()) {
			   Person person = personOptional.get();
			   System.out.println(person.getFirstName());
		   }else {
			   System.out.println("No person found");
		   }
		   
	}

	public static Optional<Person> findPerson(List<Person> people, String name) {
		for (Person person : people) {
			if (person.getFirstName().equals(name)) {
				return Optional.of(person);
			}
		}
		return Optional.empty();
	}

}
