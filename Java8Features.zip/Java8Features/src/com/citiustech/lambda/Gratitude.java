package com.citiustech.lambda;

public interface Gratitude {

	void performGratitude();
	
//	void performGratitude(String language);
}
