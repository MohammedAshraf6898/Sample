package com.citiustech.lambda;

public class GratitudeMain {

	public void printGratitude(Gratitude gratitude) {
		gratitude.performGratitude();
	}

	public static void main(String[] args) {
//		GratitudeMain main = new GratitudeMain();
//		MarathiGratitude marathiGratitude = new MarathiGratitude();
//		main.printGratitude(marathiGratitude);

//		Gratitude gratitudeMarathi = () -> System.out.println("Dhanywaad :)"); 
//		gratitudeMarathi.performGratitude();
//		Gratitude gratitudeEnglish = () -> System.out.println("Thank you :)");
//		gratitudeEnglish.performGratitude();

		GetLength g1 = (s) -> System.out.println(s.length());
		g1.getStringLength("Abhishek__");
	}

}
