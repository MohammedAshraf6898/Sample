package com.citiustech.lambda;

public class MarathiGratitude/* implements Gratitude */{

//	@Override
	public void performGratitude() {
		System.out.println("Dhanywaad :)");
	}

}
