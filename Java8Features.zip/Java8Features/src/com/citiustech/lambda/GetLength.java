package com.citiustech.lambda;

public interface GetLength {
	void getStringLength(String message);
}
