package com.citiustech.employeeDao;

import java.util.HashSet;
import java.util.Set;


public class EmployeeDao {

	private Set<Employee> set = new HashSet<>();

	public void addEmployee(Employee employee) {
		set.add(employee);
	}

	public void updateEmployee(Employee employee) {

	}

	public void deleteEmployee(int empId) {

	}

	public HashSet<Employee> getAllEmployees() {
//		HashSet<Employee> employeeSet = new HashSet<>();

		return (HashSet<Employee>) set;
	}

}
