package com.citiustech.employeeDao;


public class EmployeeHashSetMain {

	public static void main(String[] args) {
		EmployeeDao dao = new EmployeeDao();
		Employee e1 = new Employee(101,"Tom", 10000d);
		Employee e2 = new Employee(102,"Jerry", 15000d);
		Employee e3 = new Employee(103,"Butch", 50000d);
		Employee e4 = new Employee(103,"Butch", 50000d);

		dao.addEmployee(e1);
		System.out.println("-------------");
		dao.addEmployee(e2);
		System.out.println("-------------");
		dao.addEmployee(e3);
		System.out.println("-------------");
		dao.addEmployee(e4);		

		for(Employee emp : dao.getAllEmployees()) {
			System.out.println(emp);
		}
	}
}
