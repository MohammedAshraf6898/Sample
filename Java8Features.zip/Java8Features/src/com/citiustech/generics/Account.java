package com.citiustech.generics;

public class Account {

	public void accountTransaction() {
		System.out.println("Doing account transactions");
	}
}
