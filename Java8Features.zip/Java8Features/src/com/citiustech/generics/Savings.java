package com.citiustech.generics;

public class Savings extends Account {
	
	public void accountTransaction() {
		System.out.println("Saving Account Transactions");
	}
	
}
