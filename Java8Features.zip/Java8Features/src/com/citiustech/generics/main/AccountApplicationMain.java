package com.citiustech.generics.main;

import java.util.ArrayList;
import java.util.List;

import com.citiustech.generics.Account;
import com.citiustech.generics.Current;
import com.citiustech.generics.Savings;

public class AccountApplicationMain {

	public static void main(String[] args) {
		System.out.println("Start");
		Account account = new Account();
		Current current = new Current();
		Savings savings = new Savings();
		account = current;
		account = savings;

		ArrayList<Account> accountList = new ArrayList<Account>();
		accountList.add(account);
		accountList.add(current);
		accountList.add(savings);

		ArrayList<Savings> savingList = new ArrayList<>();
		savingList.add(savings);
//		accountList = savingList; //compile time error

		ArrayList<Current> currentList = new ArrayList<Current>();

		// Generics wildcard
		ArrayList<?> acountList2 = new ArrayList<Savings>();
		acountList2 = savingList;

		// Wildcard Boundary
		List<? extends Account> listAccount3 = new ArrayList<Account>();
		listAccount3 = accountList;
		listAccount3 = savingList;
		listAccount3 = currentList;
		
//		printAccountTransactions(accountList);
		
		
		// Super Wildcard Boundary
		List<? super Account> listAccount4 = new ArrayList<Account>();
		listAccount4 = accountList;
//		listAccount4 = savingList;
//		listAccount4 =currentList;

		printAccountTransactions(listAccount4);

		
		System.out.println("End");
	}

//	public static void printAccountTransactions(List<? extends Account> accounts) {
//
//		for (Account account : accounts) {
//			account.accountTransaction();
//		}
//	}
	public static void printAccountTransactions(List<? super Account> accounts) {

		for (Account account : (ArrayList<Account>)accounts) {
			account.accountTransaction();
		}
	}
}
