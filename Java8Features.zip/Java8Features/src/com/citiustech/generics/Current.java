package com.citiustech.generics;

public class Current extends Account {

	@Override
	public void accountTransaction() {
		System.out.println("Current Account Transactions");
	}
}
