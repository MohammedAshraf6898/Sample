package com.citiustech.exam;

public class Exam {

	public static void main(String[] args) {
	}
}
