package com.citiustech.map;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HashMapAndConcurrentHashMap {

	public static void main(String[] args) {
		HashMap<String, String> hm = new HashMap<>();
		hm.put("First", "1");
		hm.put("Second", "2");
		hm.put("Third", "3");
		
		System.out.println(hm);
		
//		for(String key: hm.keySet()) {
//			if(key.equals("Third")) {
//				hm.put("Fourth", "4"); // ConcurrentModificationException
//			}
//		}
//		
		ConcurrentHashMap<String,String> chm = new ConcurrentHashMap<String, String>();
		
		chm.putAll(hm);
		for(String key: chm.keySet()) {
			if(key.equals("Third")) {
				chm.put("Fourth", "4"); // ConcurrentModificationException
			}
		}
		System.out.println(chm);
	}
}
