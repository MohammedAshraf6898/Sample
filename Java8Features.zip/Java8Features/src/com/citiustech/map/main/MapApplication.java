package com.citiustech.map.main;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.citiustech.map.Employee;

public class MapApplication {

	public static void main(String[] args) {
		Map mapA = new HashMap();
		Map mapB = new TreeMap();

		mapA = new TreeMap();
		mapB = new HashMap();

		Map<Integer, Employee> empMap = new TreeMap<Integer, Employee>();
		Employee e1 = new Employee("Tom", 10000d);
		Employee e2 = new Employee("Jerry", 15000d);
		Employee e3 = new Employee("Butch", 50000d);

		empMap.put(101, e1);
		empMap.put(102, e2);
		empMap.put(103, e3);

		System.out.println(empMap);
		System.out.println("+=======================================+");

		Map<Integer, Employee> empHashMap = new HashMap<Integer, Employee>();
		empHashMap.putAll(empMap);
		System.out.println(empHashMap);
		System.out.println("+=======================================+");

		Employee empObj = empHashMap.get(102);
		System.out.println(empObj);

		System.out.println("+=======================================+");
		System.out.println(empHashMap.getOrDefault(104, new Employee()));

		System.out.println("+=======================================+");
		if (empHashMap.containsKey(104))
			System.out.println(empHashMap.get(104));
		else
			System.out.println("No key found");

		System.out.println("+=======================================+");
		Iterator<Integer> iterator = empHashMap.keySet().iterator();

		while (iterator.hasNext()) {
			int empId = iterator.next();
			Employee employee = empHashMap.get(empId);
			System.out.println(empId + " " + employee.getName() + " " + employee.getSalary());
		}

		System.out.println("+=======================================+");
		for (Integer key : empHashMap.keySet()) {
			System.out.println("Key :: " + key);
		}

		Iterator<Employee> itr = empHashMap.values().iterator();

		System.out.println("+=======================================+");
		while (itr.hasNext()) {
			Employee employee = (Employee) itr.next();
			System.out.println(employee.getName() + " " + employee.getSalary());
		}

		System.out.println("+=======================================+");
		for (Employee employee : empHashMap.values()) {
			System.out.println(employee.getName() + " " + employee.getSalary());
		}

		System.out.println("+=======================================+");
		Set<Map.Entry<Integer, Employee>> entries = empHashMap.entrySet();
		Iterator<Map.Entry<Integer, Employee>> entriesIterator = entries.iterator();

		while (entriesIterator.hasNext()) {
			Map.Entry<Integer, Employee> entry = entriesIterator.next();
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
//		empHashMap.remove(101);
//		empHashMap.clear();
		System.out.println("+=======================================+");
		for(Map.Entry<Integer, Employee> entry:entries) {
			System.out.println("key :: "+entry.getKey() + " value :: " + entry.getValue());
		}
		
		
	}

}
