package com.citiustech.complitableFuture;

public class CompletableFuture {

	public static void main(String[] args) {
		System.out.println("main-start");
		System.out.println(longNetworkProcess(5));
		System.out.println("main-end");
	}
	
	public static int longNetworkProcess(int value) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return value*10;
	}
}


// executer framework