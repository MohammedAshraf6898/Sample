package com.citius.datetimeapi;

import java.time.Duration;
import java.time.Instant;

public class InstantAndDurationTest {
	public static void main(String[] args) throws InterruptedException {
		Instant start = Instant.now();
		System.out.println(start);

		Thread.sleep(1000);

		Instant end = Instant.now();
		System.out.println(end);

		Duration elapsed = Duration.between(start, end);
		System.out.println("Milliseconds = " + elapsed.toMillis());
		System.out.println("Seconds = " + elapsed.toSeconds());
	}
}
