package com.citius.datetimeapi;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class DateTimeTest {
	public static void main(String[] args) {
		LocalDate currentDate = LocalDate.now();
		System.out.println("Current date = " + currentDate);

		LocalDate specificDate = LocalDate.of(2021, 03, 06);
		System.out.println("Specific date = " + specificDate);

		LocalTime localTime = LocalTime.now();
		System.out.println("LocalTime = " + localTime);

		LocalTime specificTime = LocalTime.of(14, 8);
		System.out.println("Specific time = " + specificTime);

		LocalDateTime specificDateTime = LocalDateTime.of(specificDate, specificTime);
		System.out.println("Local Date Time = " + specificDateTime);
		
		Period period = Period.between(specificDate, currentDate);
		System.out.println("Year difference = "+period.getYears());
		System.out.println("Month difference = "+period.getMonths());
		System.out.println("Day difference = "+period.getDays());
	}
}
