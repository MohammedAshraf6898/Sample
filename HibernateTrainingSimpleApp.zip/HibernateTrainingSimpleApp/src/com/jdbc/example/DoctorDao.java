package com.jdbc.example;

public interface DoctorDao {

}
