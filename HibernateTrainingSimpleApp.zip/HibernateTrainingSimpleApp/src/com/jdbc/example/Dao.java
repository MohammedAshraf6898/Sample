package com.jdbc.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Dao {

	public static Connection getDbConnection() {
		Connection c = null;
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/hibernateTraining", "postgres",
					"password_123");
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Opened database successfully");
		return c;
	}

	public static void saveDoctor() {
		try {
			Connection connection = getDbConnection();
			Statement stmt = null;
			stmt = connection.createStatement();
			String sql;
			sql = "INSERT INTO tbl_Doctor " + "VALUES (11, 'Allen', 'allen@gmail.com');";
			stmt.executeUpdate(sql);

			sql = "INSERT INTO tbl_Doctor " + "VALUES (12, 'Paul', 'paul@gmail.com');";
			stmt.executeUpdate(sql);
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Doctor data inserted successfully");
	}

	public static void savePatient() {
		try {
			Connection connection = getDbConnection();
			Statement stmt = null;
			stmt = connection.createStatement();
			String sql;
			sql = "INSERT INTO tbl_patient VALUES (1, 10,'Tom', 'tom@gmail.com');";
			stmt.executeUpdate(sql);

			sql = "INSERT INTO tbl_patient VALUES (2, 10,'Jerry', 'jerry@gmail.com');";
			stmt.executeUpdate(sql);

			sql = "INSERT INTO tbl_patient VALUES (3, 11,'Butch', 'butch@gmail.com');";
			stmt.executeUpdate(sql);
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Patient data inserted successfully");
	}
	
	public static void main(String args[]) {
//		saveDoctor();
		savePatient();
	}
	
}
