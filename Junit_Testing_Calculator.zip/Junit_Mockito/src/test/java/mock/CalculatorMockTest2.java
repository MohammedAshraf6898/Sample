package mock;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

	 

	public class CalculatorMockTest2 {
	    private CalculatorMock c = mock(CalculatorMock.class);
	    
	    
	    @Test
	    public void addTest() {
	        when(c.add(10, 20)).thenReturn(30);
	        when(c.add(100, 100)).thenCallRealMethod();
	        assertEquals(30, c.add(10,20));
	        assertEquals(200, c.add(100,100));
	        
	        verify(c,times(2)).add(Mockito.anyInt(), Mockito.anyInt());
	    
	    }

	 

	    @Test
	    public void divTest() {
	        when(c.div(10, 0)).thenThrow(ArithmeticException.class);
	    
	        assertThrows(ArithmeticException.class,()->{
	            int x = c.div(10, 0);
	        });
	            
	        
	    }
	    
	    @Test
	    public void testsq() {
	        ArgumentCaptor<Integer> cap = ArgumentCaptor.forClass(Integer.class);
	        when(c.sq(10)).thenReturn(100);
	        assertEquals(100, c.sq(10));
	        verify(c).sq(cap.capture());
	        assertEquals(10,cap.getValue());
	    }

	 

	    @Test
	    public void addcap() {
	        ArgumentCaptor<Integer> capa = ArgumentCaptor.forClass(Integer.class);
	        ArgumentCaptor<Integer> capb = ArgumentCaptor.forClass(Integer.class);

	 

	        when(c.add(10, 20)).thenReturn(30);
	        assertEquals(30, c.add(10,20));
	        verify(c).add(capa.capture(),capb.capture());
	        assertEquals(10,capa.getValue());
	        assertEquals(20,capb.getValue());
	    }

	 

}
