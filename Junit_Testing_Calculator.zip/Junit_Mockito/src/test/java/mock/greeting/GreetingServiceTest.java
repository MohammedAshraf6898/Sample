package mock.greeting;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class GreetingServiceTest {

	private GreetingService gs;
	private GreetingRepository gp = mock(GreetingRepository.class);

	@Test
	public void greetTest() {
		gs = new GreetingService(gp);
		when(gp.greet()).thenReturn(new String[] { "Hello", "Hi" });

		assertArrayEquals(new String[] { "Hello", "Hi" }, gs.greet());
	}

	@Test
	public void findFirstTest() {
		gs = new GreetingService(gp);
		when(gp.greet()).thenReturn(new String[] { "Hello", "Hi" });

		assertEquals("Hello", gs.getFirst());
		verify(gp).greet();
	}

}
