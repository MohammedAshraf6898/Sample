package mock;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CalculatorMockTest {

	@Test
	public void addTest() {
		CalculatorMock c = mock(CalculatorMock.class);
		when(c.add(10, 20)).thenReturn(30);
		when(c.add(100, 100)).thenCallRealMethod();
		assertEquals(30, c.add(10, 20));
		assertEquals(200, c.add(100, 100));

		verify(c, times(2)).add(Mockito.anyInt(), Mockito.anyInt());

	}

	@Test
	public void divTest() {
		CalculatorMock c = mock(CalculatorMock.class);
		when(c.div(10, 0)).thenThrow(ArithmeticException.class);

		assertThrows(ArithmeticException.class, () -> {
			int x = c.div(10, 0);
		});

	}

}
