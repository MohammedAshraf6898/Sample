package mock.greeting;

public class GreetingService {
	private GreetingRepository repo;

	public GreetingService(GreetingRepository repo) {
		this.repo = repo;
	}

	public String[] greet() {
		return repo.greet();
	}

	public String getFirst() {
        return repo.greet()[0];
        
    }
}