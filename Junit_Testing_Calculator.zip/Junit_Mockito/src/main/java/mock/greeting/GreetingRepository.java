package mock.greeting;

public class GreetingRepository {
	public String[] greet() {

		return new String[] { "Hello", "Hi" };
	}
}