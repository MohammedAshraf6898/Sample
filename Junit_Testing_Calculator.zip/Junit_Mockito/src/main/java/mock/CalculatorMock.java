package mock;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CalculatorMock {

	public int add(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		CalculatorMock c= mock(CalculatorMock.class);
		when(c.add(10, 100)).thenReturn(110);
		
		
	}

	public int div(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer sq(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
