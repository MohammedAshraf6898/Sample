package mock;

import java.util.List;
import static org.mockito.Mockito.mock;

public class Mock {

	public static void main(String[] args) {

		List<String> cities = mock(List.class);

		System.out.println(cities.get(0));
		cities.add("Munich");
		System.out.println(cities.get(0));

	}

}
