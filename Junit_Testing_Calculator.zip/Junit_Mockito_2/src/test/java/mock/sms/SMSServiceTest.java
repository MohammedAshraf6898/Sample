package mock.sms;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SMSServiceTest {
    
    @Mock
    private SMSService ss;
    
    @Test
    public void testsendSMS() {
        when(ss.sendSMS()).thenReturn(true);
        when(ss.resendSMS()).thenReturn(true);
        assertTrue(ss.sendSMS());
        assertTrue(ss.resendSMS());
    }
}