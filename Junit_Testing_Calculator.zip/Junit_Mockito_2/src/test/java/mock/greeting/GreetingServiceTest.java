package mock.greeting;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GreetingServiceTest {
	private GreetingService gs;
	@Mock
	private GreetingRepository gp;

	@BeforeEach
	public void setup() {
		gs = new GreetingService(gp);
	}

	@Test
	public void greetTest() {
		when(gp.greet()).thenReturn(new String[] { "Hello", "Hi" });
		assertArrayEquals(new String[] { "Hello", "Hi" }, gs.greet());
	}

	@Test
	public void findFirstTest() {
		when(gp.greet()).thenReturn(new String[] { "Hello", "Hi" });

		assertEquals("Hello", gs.getFirst());
		verify(gp).greet();
	}

}