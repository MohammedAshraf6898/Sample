package mock.product.copy;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class CustomerServiceTest {

	@Mock
	CustomerService cs = new CustomerService();
	
	@Test
	void test() {
	}

}
