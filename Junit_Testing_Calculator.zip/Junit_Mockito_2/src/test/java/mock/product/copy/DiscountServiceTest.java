package mock.product.copy;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import mock.product.DiscountService;
import mock.product.Product;

class DiscountServiceTest {

	private DiscountService ds;
	@Mock
	private CustomerService ps;

	private List<Customer> customerList = new ArrayList<>();

	@BeforeEach
	public void setup() {
		customerList.add(new Customer(1, "John", "Gold"));
		customerList.add(new Customer(2, "Jerry", "Silver"));
	}

	
	@Test
	void test() {

	}

}
