package mock.product;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DiscountServiceTest {
	// SUT
	private DiscountService ds;
	@Mock
	private ProductService ps;

	private List<Product> products = new ArrayList<Product>();

	@BeforeEach
	public void setup() {
		products.add(new Product(1, "Mouse", 500));
		products.add(new Product(2, "Key Board", 600));
	}

	@Test
	public void testapplyDiscount() {
		ds = new DiscountService(ps);
		when(ps.getAll()).thenReturn(products);

		List<Product> prds = ds.applyDiscount(10);
		assertEquals(prds.get(0).getPrice(), 490);
		assertEquals(prds.get(1).getPrice(), 590);
	}
}
