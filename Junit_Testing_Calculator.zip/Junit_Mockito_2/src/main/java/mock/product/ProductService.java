package mock.product;

import java.util.ArrayList;
import java.util.List;

public class ProductService {

	private List<Product> products = new ArrayList<>();

	public ProductService() {
		products.add(new Product(1, "Mouse", 500));
		products.add(new Product(2, "Key Board", 600));
	}

	public List<Product> getAll() {
		return products;
	}
}