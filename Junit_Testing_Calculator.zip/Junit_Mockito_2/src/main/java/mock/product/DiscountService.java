package mock.product;

import java.util.ArrayList;
import java.util.List;

public class DiscountService {
	private ProductService ps;

	public DiscountService(ProductService ps) {
		this.ps = ps;
	}

	public List<Product> applyDiscount(int n) {
		List<Product> products = ps.getAll();
		List<Product> dproducts = new ArrayList<>();
		for (Product p : products) {
			dproducts.add(new Product(p.getId(), p.getName(), p.getPrice() - n));
		}
		return dproducts;
	}

}