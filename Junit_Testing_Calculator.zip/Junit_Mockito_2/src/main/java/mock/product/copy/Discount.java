package mock.product.copy;

public class Discount {

	private String group;
	private int dis;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getDis() {
		return dis;
	}

	public void setDis(int dis) {
		this.dis = dis;
	}

	public Discount() {
		// TODO Auto-generated constructor stub
	}

	public Discount(String group, int dis) {
		this.group = group;
		this.dis = dis;
	}

}