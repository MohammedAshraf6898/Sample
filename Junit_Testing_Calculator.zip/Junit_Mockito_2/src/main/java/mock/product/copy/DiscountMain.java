package mock.product.copy;

import java.util.List;

public class DiscountMain {

	public static void main(String[] args) {

		ProductService ps = new ProductService();
		CustomerService cs = new CustomerService();
		DiscountService ds = new DiscountService(ps, cs);
		List<Product> products = ds.applyDiscount(10);
		products.stream().forEach(System.out::println);

		Customer c = new Customer(1, "John", "Gold");

		int d = ds.getDiscountForCustomer(c);
		System.out.println(d);
	}
}