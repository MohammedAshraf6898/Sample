package mock.product.copy;

import java.util.ArrayList;
import java.util.List;

public class CustomerService {
    private List<Customer> customers = new ArrayList<Customer>();
    
    public CustomerService() {
        customers.add(new Customer(1,"John","Gold"));
        customers.add(new Customer(2,"James","Silver"));
            
        }
    
    public List<Customer> getCustomers(){
        return customers;
    }
    
    

 

}
