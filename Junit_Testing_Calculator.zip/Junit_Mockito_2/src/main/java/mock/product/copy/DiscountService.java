package mock.product.copy;

import java.util.ArrayList;
import java.util.List;

public class DiscountService {
	private ProductService ps;
	private CustomerService cs;
	private List<Discount> discounts = new ArrayList<Discount>();

	public DiscountService() {
		discounts.add(new Discount("Gold", 20));
		discounts.add(new Discount("Silver", 10));

	}

	public List<Discount> getAll() {
		return discounts;
	}

	public int getDiscountForCustomer(Customer c) {
		String grp = "";
		List<Customer> customers = cs.getCustomers();
		for (Customer customer : customers) {
			if (customer.getId() == c.getId()) {
				grp = c.getGroup();
			}
		}

		for (Discount disc : this.discounts) {
			System.out.println("disc :" + disc.getDis());
			if (disc.getGroup().equals(grp)) {
				return disc.getDis();
			}
		}
		return 0;

	}

	public DiscountService(ProductService ps, CustomerService cs) {
		this();
		this.ps = ps;
		this.cs = cs;
	}

	public List<Product> applyDiscount(int n) {

		List<Product> products = ps.getAll();
		List<Product> dproducts = new ArrayList<Product>();

		for (Product p : products) {
			dproducts.add(new Product(p.getId(), p.getName(), p.getPrice() - n));
		}
		return dproducts;

	}

}
