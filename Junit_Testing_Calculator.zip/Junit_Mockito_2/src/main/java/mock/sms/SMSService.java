package mock.sms;

public class SMSService {

	public boolean sendSMS() {
		System.out.println("Sending SMS");
		return true;
	}
	public boolean resendSMS() {
		System.out.println("resending SMS");
		return true;

	}

}
