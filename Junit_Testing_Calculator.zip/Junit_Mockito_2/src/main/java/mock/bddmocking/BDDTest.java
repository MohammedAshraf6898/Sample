package mock.bddmocking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.BDDMockito;

public class BDDTest {
	private List<String> msgs = mock(ArrayList.class);

	@Test
	public void m1() {
		// given
		BDDMockito.given(msgs.get(0)).willReturn("hello");
		// when
		String txt = msgs.get(0);
		// then
		assertEquals(txt, "hello");
	}
}
