package com.junit.examples;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	private Calculator calculator = new CalculatorImpl();

	@Test
	@DisplayName("Addition")
	void testAdd() {
		assertEquals(20, calculator.add(10, 10));
	}

	@Test
	@DisplayName("Multiplication")
	void testMul() {
		assertEquals(100, calculator.mul(10, 10));
	}

	@Test
	@DisplayName("Subtraction")
	void testSub() {
		assertEquals(10, calculator.sub(20, 10));
	}

	@Test
	@DisplayName("Division")
	void testDiv() {
		assertEquals(1, calculator.div(10, 10));
	}
}
