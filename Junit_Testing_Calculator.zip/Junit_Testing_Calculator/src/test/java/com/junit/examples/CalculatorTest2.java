package com.junit.examples;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

 

public class CalculatorTest2 {
    
    private Calculator calc;
    
    @BeforeAll
    public static void init() {
        System.out.println("before all...");
        
    }
    @BeforeEach
    public void setup() {
        System.out.println("before each...");
        calc =  new CalculatorImpl();
    }
    
@RepeatedTest(2)
    public void addtest() {
        assertEquals(10, calc.add(6, 4));
        assertTimeout(Duration.ofMillis(1000), ()->{
            calc.add(10, 20);
        });
        
    }
    @Test
    @DisplayName("sub....")
    public void subtest() {
        assertEquals(10, calc.sub(20, 10));
    }
    @Test
    public void multest() {
        assertEquals(10, calc.mul(2, 5));
    }
    @Test
    public void divtest() {
        assertEquals(10, calc.div(20, 2));
        assertThrows(ArithmeticException.class, ()->{
            calc.div(10, 0);
        });
    }
    
    @Test
    public void addxtest() {
        assertAll(()->{
            assertEquals(30,calc.add(10, 20));
        },()->{
            assertEquals(30,calc.add(20, 10));
        });
    }
    
    
//    @Test
//    public void sqtest() {
//        assertEquals(25, calc.sq(5));
//    }

 

    
    
//    @ParameterizedTest
//    @ValueSource(ints = {3,7,5,11})
//    public void oddtest(int n) {
//        assertTrue(calc.odd(n));
//    }
    
    @AfterEach
    public void tearDown() {
        System.out.println("after each...");
        calc = null;
        }
    

 

    @AfterAll
    public static void destroy() {
        System.out.println("after  all...");
    }
}