package com.junit.pro;

public abstract class AbstractAuthService implements IAuthService{

	 

    public abstract boolean check(String login, String pass);
}