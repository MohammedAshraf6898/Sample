package com.junit.pro;

public interface IAuthService {
    public boolean check(String login, String pass);
}