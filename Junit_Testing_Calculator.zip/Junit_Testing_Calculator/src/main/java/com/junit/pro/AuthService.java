package com.junit.pro;

public class AuthService extends AbstractAuthService{
@Override
public boolean check(String login, String pass) {
    if(login.equals("Jack") && pass.equals("Sparrow"))
        return true;
    else
        return false;
    
}
}