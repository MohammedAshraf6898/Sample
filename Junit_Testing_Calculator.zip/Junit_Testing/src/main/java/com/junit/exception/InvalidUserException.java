package com.junit.exception;

public class InvalidUserException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -744628819284529033L;

	public InvalidUserException(String msg) {
		super(msg);
	}
}