package com.citius.jwt;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class Application {
	    
	    
	    public static void main(String[] args) {
	        
	        JwtUtil jt = new JwtUtil();
	        User ud = new User("John","1234",Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN")));
	        
	        String token = jt.generateToken(ud);
	        
	        String uname = jt.extractUsername(token);
	        
	        System.out.println(token);
	        System.out.println(uname);
	        
	        
	    }
}
