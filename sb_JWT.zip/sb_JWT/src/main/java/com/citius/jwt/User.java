package com.citius.jwt;

public class User {

}
