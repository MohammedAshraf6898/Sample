package com.citius.sb;

import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderService {
    
//pointcut expression (matching points) *.com.citius.simple.*.(..)
//apply loggingservice.log for all classes in com.citius.simple
    public void placeOrder()
    {    
        //before - advice
        System.out.println("Order placed...");
        //after - advice

 

    }
    public void getDatfromcart()
    {    
        //before - advice
        System.out.println("getting data rom cart...");
        //after - advice

 

    }
    
    

 

}