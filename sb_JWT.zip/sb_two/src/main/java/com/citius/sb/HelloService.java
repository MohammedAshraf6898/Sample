package com.citius.sb;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloService {

//	List<Message> messages = new ArrayList<>();
//
//	public HelloService() {
//		messages.add(new Message(1, "Hello!!"));
//		messages.add(new Message(2, "World!!"));
//
//	}

	@GetMapping("/hello")
	public String sayHello() {
		return "Abhishek Altekar";
	}

}