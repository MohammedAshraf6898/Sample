package com.citius.jpapro.facade;

import java.util.List;

import com.citius.jpapro.dto.CustomerDTO;
import com.citius.jpapro.model.Customer;

public interface CustomerFacade {

	public List<CustomerDTO> getAll();

	public void saveCustomer(CustomerDTO c);
	public CustomerDTO getCustomerById(int id);
	public void deleteCustomerById(int id);
	public void updateCustomer(CustomerDTO c);
}
