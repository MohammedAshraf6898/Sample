package com.citius.jpapro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citius.jpapro.dao.CustomerDAO;
import com.citius.jpapro.model.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public List<Customer> getCustomers() {
		return customerDAO.findAll();
	}

	@Override
	public void saveCustomer(Customer c) {
		System.out.println("save invoked");
		customerDAO.save(c);
	}

	@Override
	public Customer getCustomerById(int id) {
		return customerDAO.findById(id);
	}

	public void deleteCustomerById(int id) {
		customerDAO.deleteById(id);
	}

	@Override
	public void updateCustomer(Customer c) {
		customerDAO.save(c);
	}
}
