package com.citius.jpapro.service;

import java.util.List;

import com.citius.jpapro.model.Customer;

public interface CustomerService {
	public List<Customer> getCustomers();
	public void saveCustomer(Customer c);
	public Customer getCustomerById(int id);
	public void deleteCustomerById(int id);
	public void updateCustomer(Customer c);
}
