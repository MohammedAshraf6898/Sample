package com.citius.jpapro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.citius.jpapro.dto.CustomerDTO;
import com.citius.jpapro.facade.CustomerFacade;

@RestController
public class CustomerPageController {

	@Autowired
	private CustomerFacade customerFacade;

	@GetMapping("/customers")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<CustomerDTO> getCustomers() {
		return customerFacade.getAll();
	}

	@PostMapping("/customers")
	public void saveCustomer(@RequestBody CustomerDTO c) {
		customerFacade.saveCustomer(c);
	}

	@GetMapping("/customers/{id}")
	public CustomerDTO getCustomersById(@PathVariable int id) {
		return customerFacade.getCustomerById(id);
	}

	@DeleteMapping("/customers/{id}")
	public void deleteCustomerById(@PathVariable int id) {
		customerFacade.deleteCustomerById(id);
	}

	@PutMapping("/customers/{id}")
	public void updateCustomerById(@PathVariable int id, @RequestBody CustomerDTO c) {
		c.setId(id);
		System.out.println(c + "\n" + id);
		customerFacade.updateCustomer(c);

	}
}
