package com.citius.jpapro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.citius.jpapro.dao.CustomerDAO;
import com.citius.jpapro.model.Customer;

@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private CustomerDAO customerDAO;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// save();
		// findAll();
		// findById(2);
		// findByEmail("jerry@gmail.com");
		// findCustomerPage();
	}

	private void save() {
		Customer c = new Customer("Jerry", "jerry@gmail.com");
		customerDAO.save(c);
		System.out.println("saved.....");
	}

	private void findAll() {
		customerDAO.findAll().stream().forEach(System.out::println);

	}

//	private void findById(int i) {
//		Optional<Customer> c = customerDAO.findById(i);
//		System.out.println(c.get());
//
//	}
	private void findByEmail(String email) {
		Customer c = customerDAO.findByEmail(email);
		System.out.println(c);

	}

	public void findCustomerPage() {
		Page<Customer> customers = customerDAO.findCustomersWithPg(PageRequest.of(0, 4));
		customers.stream().forEach(System.out::println);
	}

//	@Bean
//	public PasswordEncoder encode() {
//		return new BCryptPasswordEncoder();
//	}
}
