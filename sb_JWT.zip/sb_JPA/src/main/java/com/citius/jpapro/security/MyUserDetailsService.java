package com.citius.jpapro.security;

import java.util.ArrayList;
import java.util.List;

 

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

 

@Service
public class MyUserDetailsService implements UserDetailsService {
    private List<MyUserDetails> userstore = new ArrayList<MyUserDetails>();

 

    public MyUserDetailsService() {
        MyUserDetails u1 = new MyUserDetails();
        u1.setUsername("john");
        u1.setPassword("{noop}1234");
        List<GrantedAuthority> rolesx = new ArrayList<GrantedAuthority>();
        rolesx.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        u1.setAuthorities(rolesx);
        
        MyUserDetails u2 = new MyUserDetails();
        u2.setUsername("winston");
        u2.setPassword("{noop}1234");
        List<GrantedAuthority> rolesy = new ArrayList<GrantedAuthority>();
        rolesy.add(new SimpleGrantedAuthority("ROLE_DEV"));
        u2.setAuthorities(rolesy);
        
        
        userstore.add(u1);
        userstore.add(u2);
        
    }
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        
        
        for (MyUserDetails myUserDetails : userstore) {
            if (myUserDetails.getUsername().equals(username)) {
                return myUserDetails;
            }
        }
        return null;
    }
}