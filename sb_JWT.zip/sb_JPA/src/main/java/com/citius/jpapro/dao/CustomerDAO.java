package com.citius.jpapro.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citius.jpapro.model.Customer;

@Repository
public interface CustomerDAO extends CrudRepository<Customer, Integer> {

public List<Customer> findAll();
public Customer findByEmail(String email);
public Customer findByEmailAndName(String email,String name);
public Customer findById(int id);

@Query("select c from Customer c")
Page<Customer> findCustomersWithPg(Pageable pageable);
}
