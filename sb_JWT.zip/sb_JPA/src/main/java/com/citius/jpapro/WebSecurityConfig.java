package com.citius.jpapro;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

//@EnableWebSecurity // first and second approach
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("john").password("{noop}1234").roles("ADMIN").and().withUser("winston")
				.password("{noop}1234").roles("DEV");

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/customers").hasAnyRole("ADMIN", "DEV")
//        .antMatchers("/").permitAll().and().formLogin();
				.antMatchers("/").permitAll().and().httpBasic();
	}
}