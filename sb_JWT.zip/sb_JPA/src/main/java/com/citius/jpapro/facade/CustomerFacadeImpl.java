package com.citius.jpapro.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citius.jpapro.dto.CustomerDTO;
import com.citius.jpapro.model.Customer;
import com.citius.jpapro.service.CustomerService;

@Service
public class CustomerFacadeImpl implements CustomerFacade{
	@Autowired
	private CustomerService customerService;
	
	@Override
	public List<CustomerDTO> getAll() {
		List<Customer> customers = customerService.getCustomers();
		List<CustomerDTO> dtos = new ArrayList<>();
		for (Customer c : customers) {
			dtos.add(new CustomerDTO(c.getId(),c.getName(),c.getEmail()));
		}
		return dtos;
	}

	@Override
	public void saveCustomer(CustomerDTO cdto) {
		Customer c = new Customer(cdto.getName(),cdto.getEmail());
		customerService.saveCustomer(c);
		
	}

	@Override
	public CustomerDTO getCustomerById(int id) {
		Customer c = customerService.getCustomerById(id);
		return new CustomerDTO(c.getId(), c.getName(), c.getEmail());
	}

	@Override
	public void deleteCustomerById(int id) {
		customerService.deleteCustomerById(id);
	}
	
	@Override
	public void updateCustomer(CustomerDTO c) {
		Customer cin = new Customer(c.getName(), c.getEmail());
		System.out.println("cin "+ cin);
		cin.setId(c.getId());
		customerService.updateCustomer(cin);
	}
}
