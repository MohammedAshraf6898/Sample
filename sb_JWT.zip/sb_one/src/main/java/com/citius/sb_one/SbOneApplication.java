package com.citius.sb_one;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbOneApplication implements CommandLineRunner {

	@Autowired
	private ProductDAO productDAO;

	public static void main(String[] args) {
		SpringApplication.run(SbOneApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<Product> products = productDAO.findAll();
		products.stream().forEach(System.out::println);

	}

}
