package com.citius.sb_one;

import java.util.List;

public interface ProductDAO {
	public List<Product> findAll();
}
