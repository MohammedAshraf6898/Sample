package com.surya.jwtdemo;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CitiesController {

	@GetMapping("/cities")
	public List<String> firstPage() {
		String cities[] = {"Munich","Berlin","Seatle"};
		return Arrays.asList(cities);
	}

}