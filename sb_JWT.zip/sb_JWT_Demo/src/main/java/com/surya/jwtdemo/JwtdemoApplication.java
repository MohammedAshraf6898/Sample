package com.surya.jwtdemo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



//https://bcrypt-generator.com/
//http://localhost:8080/authenticate

/*
 * {
*"username":"John",
*"password":"123"
}
  */
@SpringBootApplication
public class JwtdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtdemoApplication.class, args);
	}

}
