
public class ServiceC {
	    
	    public void  m3() {
	        System.out.println("This is m3()...");
	        
	    }
	 
}
