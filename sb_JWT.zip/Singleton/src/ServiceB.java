
public class ServiceB {

private ServiceC serviceC;
    public ServiceB(ServiceC serviceC) {
    this.serviceC = serviceC;
}

 


    public void  m2() {
        System.out.println("This is m2()...");
        serviceC.m3();
        
    }
    
}
 



