
public class ServiceA {
    private ServiceB serviceB;
    
    
    public ServiceA(ServiceB serviceB) {
            this.serviceB = serviceB;
    }

 


    public void  m1() {
        System.out.println("This is m1()...");
        serviceB.m2();
        
    }

 


}