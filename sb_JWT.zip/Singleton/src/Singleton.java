public class Singleton {

	private static String con;
	
	private Singleton() {
		// TODO Auto-generated constructor stub
	}
	
	public static String getConnection() {
		con ="Db connection object";
		return con;
	}
	
}
