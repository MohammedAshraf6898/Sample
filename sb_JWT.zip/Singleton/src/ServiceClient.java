
public class ServiceClient {

	public static void main(String[] args) {
		ServiceA sa = Container.getServiceA();
		sa.m1();
	}
}