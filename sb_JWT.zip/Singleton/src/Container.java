
public class Container {

	private static ServiceA a;
	private Container() {
		// TODO Auto-generated constructor stub
	}
	
	
	public static ServiceA getServiceA() {
		ServiceC sc = new ServiceC();
	    ServiceB sb = new ServiceB(sc);
	    ServiceA sa = new ServiceA(sb);
	    return sa;
	}
}
