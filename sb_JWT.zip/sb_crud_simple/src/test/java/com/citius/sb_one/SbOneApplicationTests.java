package com.citius.sb_one;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
