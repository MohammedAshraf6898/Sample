package com.citius.sb;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloService {

	List<Message> messages = new ArrayList<>();

	public HelloService() {
		messages.add(new Message(1, "Hello!!"));
		messages.add(new Message(2, "World!!"));
	}

	@GetMapping(value = "/hello")
	public List<Message> displayMessage() {
		return messages;
	}

	@PostMapping(value = "/hello")
	public HttpStatus addMessage(@RequestBody Message m) {
		messages.add(m);
		return HttpStatus.OK;
	}

	@DeleteMapping(value = "/hello/{id}")
	public HttpStatus delMessage(@PathVariable("id") int id) {
		int i = -1;
		for (int x = 0; i < messages.size(); x++) {
			if (messages.get(x).getId() == id) {
				i = x;
				break;
			} 
		}
		System.out.println(i);
		messages.remove(i);

		return HttpStatus.OK; 
	}

}
