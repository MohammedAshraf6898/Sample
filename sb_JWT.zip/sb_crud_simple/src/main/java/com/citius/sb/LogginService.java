package com.citius.sb;

import java.time.LocalDateTime;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

//aspect or cross cutting ...
@Component
@Aspect
public class LogginService {
	@Before("execution (* com.citius.sb.OrderService.*(..))")
	public void doLogx() {
		System.out.println("before logging.." + LocalDateTime.now());
	}
	
	@After("execution (* com.citius.sb.OrderService.*(..))")
	public void doLogy(JoinPoint jp) {
		System.out.println(jp);
		System.out.println("after logging.." + LocalDateTime.now());
	}
	
	
}
