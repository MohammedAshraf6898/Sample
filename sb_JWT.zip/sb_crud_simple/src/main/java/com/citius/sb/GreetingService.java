package com.citius.sb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("greetingService")
public class GreetingService {
	
	@Autowired
	private MyAppConfig myappconfig;
	
	@Value("${citius.name}")
	private String name;

	@Value("${citius.location}")
	private String location;

	
	public String  greet() {
		//return name + " : " + location;
		return myappconfig.getName() + " : " + myappconfig.getLocation() + " : " + myappconfig.getTech();
		
	}

}
