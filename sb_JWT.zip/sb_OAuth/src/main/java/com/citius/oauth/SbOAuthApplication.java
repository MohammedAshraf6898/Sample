package com.citius.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbOAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbOAuthApplication.class, args);
	}

}
