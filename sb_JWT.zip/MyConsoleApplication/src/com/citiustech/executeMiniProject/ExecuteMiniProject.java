package com.citiustech.executeMiniProject;

import com.citiustech.impact.executor.Executer;
/**
 * @author  Abhishek Altekar
 *		Note: MiniProject is referenced project in MyConsoleApplication
 * 		main method from MiniProject is invoked
 */
public class ExecuteMiniProject {
	public static void main(String[] args) {

		Executer executer= new Executer();
		executer.consoleUI();
		
	}
}
