package com.citius.jpapro.dao;

import java.util.List;

import javax.persistence.Id;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citius.jpapro.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Id> {
	public List<User> findAll();
}
