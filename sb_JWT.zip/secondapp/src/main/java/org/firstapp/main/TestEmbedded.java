package org.firstapp.main;

import org.firstapp.model.Address;
import org.firstapp.model.Contact;
import org.firstapp.util.HibernateUtil;
import org.hibernate.Session;

public class TestEmbedded {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact contact = new Contact("Thor", "thor@gmail.com");
		Address address = new Address("Titan", "Moon", "NA");
		contact.setAddress(address);
		session.save(contact);
		session.getTransaction().commit();
		session.close();
		System.out.println("saved....");
	}
}
