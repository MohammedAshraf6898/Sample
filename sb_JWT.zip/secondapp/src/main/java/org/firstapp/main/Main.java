package org.firstapp.main;

import org.firstapp.dao.ContactDao;
import org.firstapp.dao.ContactDaoImpl;
import org.firstapp.model.Contact;
import org.firstapp.util.HibernateUtil;
import org.hibernate.Session;

public class Main {

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
//		Contact c = new Contact(1, "Jack Sparrow", "jacksparrow@gmail.com");
		Contact c = new Contact(1, "JamesBond", "jamesbond@gmail.com");
		session.save(c);
		session.getTransaction().commit();
		session.close();
	}

	private static void read() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact c = session.load(Contact.class, 1);
		System.out.printf("%s, %s", c.getName(), c.getEmail());

	}

	public static void main(String[] args) {
		ContactDao contactDao = new ContactDaoImpl();
		// Save operation
		Contact c = new Contact(4, "Jack Sparrow", "jacksparrow@gmail.com");
//		contactDao.save(c);

//		contactDao.findAll();

//		contactDao.findById(4);

//		Contact cdelete = new Contact();
//		cdelete.setId(3);
//		contactDao.delete(cdelete);
		
		c = new Contact(4, "Jack", "jacksparrow@gmail.com");
		contactDao.update(c);
		

	}
}
