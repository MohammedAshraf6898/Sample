package com.citius.productservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.citius.productservice.model.Product;

@Service
public class ProductService {

	@Autowired
	private Environment env;
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private TaxServiceProxy taxServiceProxy;
	

	private List<Product> products = new ArrayList<Product>();

	public ProductService() {
		products.add(new Product(1, "Mouse", 500, 0, 0));
		products.add(new Product(2, "Keyboard", 600, 0, 0));

	}

	public List<Product> getProducts() {
		
		for (Product p : products) {
			Map<String, Integer> params = new HashMap<>();
			params.put("id", p.getId());

			ResponseEntity<Tax> res = restTemplate.getForEntity("http://taxservice/taxes/{id}", Tax.class, params);

			Tax t = res.getBody();

			p.setTax(t.getTax());
			p.setGrossprice(p.getNetprice() + t.getTax());

		}
		return products;
	}

	public Product getProduct(int id) {

		System.out.println("service productservice from : " + env.getProperty("server.port"));
		Map<String, Integer> params = new HashMap<>();
		params.put("id", id);
		ResponseEntity<Tax> res = restTemplate.getForEntity("http://taxservice/taxes/{id}", Tax.class, params);
		Tax t = res.getBody();
	
		Product product = products.stream().filter((p) -> p.getId() == id).findFirst().get();
		product.setTax(t.getTax());
		product.setGrossprice(product.getNetprice() + product.getTax());
		return product;
	}
	public Product getProductFX(int id) {

		System.out.println("fetching productservice from[feign] : " + env.getProperty("server.port"));
		Tax t = taxServiceProxy.getTax(id);
		Product product = products.stream().filter((p) -> p.getId() == id).findFirst().get();
		product.setTax(t.getTax());
		product.setGrossprice(product.getNetprice() + product.getTax());
		return product;
	}
	
}
