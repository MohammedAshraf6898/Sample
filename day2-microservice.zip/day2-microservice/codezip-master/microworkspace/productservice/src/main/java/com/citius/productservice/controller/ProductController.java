package com.citius.productservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.citius.productservice.model.Product;
import com.citius.productservice.service.ProductService;

@RestController
public class ProductController {

	private static Logger log = LoggerFactory.getLogger(ProductController.class);
	@Autowired
	private ProductService productService;

	@GetMapping("/products")
	public List<Product> getProducts() {
		log.info("Tracing productservice:");
		return productService.getProducts();
	}

	@GetMapping("/products/{id}")
	public Product getProduct(@PathVariable int id) {
		log.info("Tracing productservice:");
		//return productService.getProduct(id);
		//call feign
		return productService.getProductFX(id);
		
	}
}
