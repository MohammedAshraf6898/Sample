package com.citius.taxservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.citius.taxservice.model.Tax;

@Service
public class TaxSevice {

	@Autowired
	private Environment env;
	
	List<Tax> taxes = new ArrayList<Tax>();

	public TaxSevice() {
		taxes.add(new Tax(1, "Mouse", 5));
		taxes.add(new Tax(2, "Keyboard", 10));
	}

	public List<Tax> getTaxes() {
		return taxes;
	}

	public Tax getTax(int id) {
		System.out.println("serving from port :" + env.getProperty("server.port"));
		return taxes.stream().filter((c) -> c.getId() == id).findFirst().get();
	}
}
