package com.citius.MSOne;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class MsOneApplication implements CommandLineRunner {

	@Autowired
	private RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public static void main(String[] args) {
		SpringApplication.run(MsOneApplication.class, args);
	}

	public void findByIdOb() {
		String url = "http://localhost:8080/contacts/{id}";
		Map<String, String> params = new HashMap<>();
		params.put("id", "1");
		Contact c = restTemplate.getForObject(url, Contact.class, params);
		System.out.println(c);

	}

	public void findByIdEx() {
		String url = "http://localhost:8080/contacts/{id}";

		Map<String, String> params = new HashMap<>();
		params.put("id", "1");

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		ResponseEntity<Contact> c = restTemplate.exchange(url, HttpMethod.GET, entity, Contact.class, params);
		System.out.println(c);
	}

	@Override
	public void run(String... args) throws Exception {
		// findById();
		// findByIdEx();
		// findAll();
		//addNewContact();
		delete();
	}

	private void findById() {
		String url = "http://localhost:8080/contacts/{id}";
		Map<String, String> params = new HashMap<>();
		params.put("id", "1");
		ResponseEntity<Contact> res = restTemplate.getForEntity(url, Contact.class, params);
		System.out.println(res.getBody() + " : " + res.getStatusCode());
	}

	private void findAll() {
		String url = "http://localhost:8080/contacts";
		Contact[] contacts = restTemplate.getForObject(url, Contact[].class);
		Arrays.asList(contacts).stream().forEach(System.out::println);

	}

	private void addNewContact() {
		String url = "http://localhost:8080/contacts";

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		Contact c = new Contact(3, "Sean", "Sean@gmail.com");

		HttpEntity<Contact> entity = new HttpEntity<Contact>(c, headers);
		ResponseEntity<Contact> res = restTemplate.exchange(url, HttpMethod.POST, entity, Contact.class);
		System.out.println(res.getStatusCode());
		findAll();
	}

	private void delete() {
		String url = "http://localhost:8080/contacts/{id}";
		Map<String, String> params = new HashMap<>();
		params.put("id", "1");
		restTemplate.delete(url,params);
		findAll();
	}
}
