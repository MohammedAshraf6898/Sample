package com.citius.MSOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
