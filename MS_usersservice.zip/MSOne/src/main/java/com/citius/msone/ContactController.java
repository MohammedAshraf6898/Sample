package com.citius.msone;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ContactController {

	List<Contact> contacts = new ArrayList<>();
	public ContactController() {
		contacts.add(new Contact(1,"John","john@gmail.com"));
		contacts.add(new Contact(2,"James","bond@gmail.com"));
	}
	@GetMapping("/contacts/{id}")
	public Contact getContacts(@PathVariable int id ) {
		
		return contacts.stream().filter((c)-> c.getId() == id).findFirst().get();
	}
	
	@GetMapping("/contacts")
	public List<Contact> getContacts( ) {
		
		return contacts;
	}
	
	@PostMapping("/contacts")
	public ResponseEntity<Contact> addContact(@RequestBody Contact c)
	{
		contacts.add(c);
		return new ResponseEntity<Contact>(c, HttpStatus.OK);

	}
}
