package com.citius.productservice.model;

public class Product {
	private int id;
	private String name;
	private int netprice;
	private int tax;
	private int grossprice;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String name, int netprice, int tax, int grossprice) {
		this.id = id;
		this.name = name;
		this.netprice = netprice;
		this.tax = tax;
		this.grossprice = grossprice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNetprice() {
		return netprice;
	}

	public void setNetprice(int netprice) {
		this.netprice = netprice;
	}

	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}

	public int getGrossprice() {
		return grossprice;
	}

	public void setGrossprice(int grossprice) {
		this.grossprice = grossprice;
	}
	
}
