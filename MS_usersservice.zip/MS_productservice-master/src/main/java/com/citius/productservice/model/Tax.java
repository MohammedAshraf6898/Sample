package com.citius.productservice.model;

public class Tax {
	private int id;
	private String name;
	private int tax;

	public Tax() {
		// TODO Auto-generated constructor stub
	}

	public Tax(int id, String name, int tax) {
	
		this.id = id;
		this.name = name;
		this.tax = tax;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}
	
}