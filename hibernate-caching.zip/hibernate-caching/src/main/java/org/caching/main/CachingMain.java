
package org.caching.main;

import java.util.List;

import javax.persistence.Query;

import org.caching.model.Contact;
import org.caching.util.HibernateUtil;
import org.hibernate.Session;

public class CachingMain {

	public static void main(String[] args) {

//		 save();
//		 read();
//		 readX();
		query();
	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact c = new Contact("James Bond", "james@gmail.com");
		session.save(c);
		session.getTransaction().commit();
		session.close();
	}

	private static void read() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact c = session.load(Contact.class, 1);
		System.out.println(c.getName() + " : " + c.getEmail());
		// -----------------------------------------------------
		System.out.println("______________________________________________________");
		c = session.load(Contact.class, 1);
		System.out.println(c.getName() + " : " + c.getEmail());
		session.getTransaction().commit();
		session.close();
	}

	private static void readX() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Contact c = session.load(Contact.class, 1);
		System.out.println(c.getName() + " : " + c.getEmail());
		session.getTransaction().commit();
		session.close();
		// -----------------------------------------------------
		System.out.println("______________________________________________________");
		session = HibernateUtil.getSession();
		session.beginTransaction();
		c = session.load(Contact.class, 1);
		System.out.println(c.getName() + " : " + c.getEmail());
		session.getTransaction().commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	private static void query() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Query query = session.createQuery("from Contact").setCacheable(true);
		List<Contact> contacts = query.getResultList();
		for (Contact c : contacts) {
			System.out.println(c.getName() + " : " + c.getEmail());
		}
		session.getTransaction().commit();
		session.close();
		// -----------------------------------------------------
		System.out.println("______________________________________________________");
		session = HibernateUtil.getSession();
		session.beginTransaction();
		query = session.createQuery("from Contact").setCacheable(true);
		contacts = query.getResultList();
		for (Contact c : contacts) {
			System.out.println(c.getName() + " : " + c.getEmail());
		}
		session.getTransaction().commit();
		session.close();
	}

}
