package org.one2one.main;

import org.hibernate.Session;
import org.one2one.model.Catalog;
import org.one2one.model.Product;
import org.one2one.util.HibernateUtil;

public class Catalog_Product {
	public static void main(String[] args) {

		save();
	}

	private static void save() {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Product p1 = new Product("Sony Camera", 10000);
		Product p2 = new Product("Canon Camera", 10000);
		session.save(p1);
		session.save(p2);

		Catalog c = new Catalog("Hobby");
		c.getProducts().add(p1);
		c.getProducts().add(p2);
		session.save(c);
		session.getTransaction().commit();
		session.close();
	}
}